"""
JARVIS Orb Overlay v2
-----------------------
- Full black background covering the whole screen by default
- Dense 3D point-cloud sphere (like a Fibonacci sphere), slowly rotating,
  front-facing dots bright/large, far-side dots dim/small -> gives real depth
- Dots pulse/brighten with TTS audio amplitude
- When JARVIS opens an app/window: black background fades away (so you see
  your desktop/app underneath) and the orb shrinks + docks to the top-right
- Message panel: black bg, blue outline, blue/white text, pops up for
  time, calendar, messages, etc.

Run with: python orb_overlay.py
Requires: pip install PyQt6 numpy
"""

import sys
import math
import random
import numpy as np
from PyQt6.QtWidgets import QApplication, QWidget, QLabel, QVBoxLayout
from PyQt6.QtCore import Qt, QTimer, QPoint, pyqtSignal, QObject
from PyQt6.QtGui import QPainter, QColor, QBrush, QPen, QFont, QGuiApplication

from clock import get_greeting_line, get_current_time_str


# ---------------------------------------------------------------------------
# Global "bus" so other modules (TTS, command handler) can talk to the GUI
# ---------------------------------------------------------------------------
class JarvisSignals(QObject):
    amplitude_changed = pyqtSignal(float)
    show_message = pyqtSignal(str, str)
    show_live_text = pyqtSignal(str, str)
    dock_to_corner = pyqtSignal(bool)
    desktop_mode = pyqtSignal(bool)
    hide_message = pyqtSignal()
    open_hud_panel = pyqtSignal(str, str)   # (panel_type, data)
    close_hud_panels = pyqtSignal()

signals = JarvisSignals()


def announce_time():
    """Call this from anywhere (voice command handler, hotkey, etc.) to have
    JARVIS speak/display the current real time."""
    signals.show_message.emit("JARVIS", get_greeting_line())


BLUE = (60, 170, 255)
BLUE_DIM = (25, 70, 120)
N_POINTS = 900  # reduced from 1600 - still looks great, ~44% faster to render


class SphereOrbWidget(QWidget):
    """Dense rotating point-cloud sphere, like a volumetric AI orb."""

    def __init__(self):
        super().__init__()
        self.amplitude = 0.0
        self.target_amplitude = 0.0
        self.phase = 0.0
        self.docked = False
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        # Precompute points evenly spread on a unit sphere (Fibonacci sphere)
        i = np.arange(0, N_POINTS)
        golden_angle = math.pi * (3 - math.sqrt(5))
        y = 1 - (i / float(N_POINTS - 1)) * 2          # -1..1
        radius_at_y = np.sqrt(np.clip(1 - y * y, 0, 1))
        theta = golden_angle * i
        self.px = np.cos(theta) * radius_at_y
        self.py = y
        self.pz = np.sin(theta) * radius_at_y
        # small per-point size jitter so it doesn't look too uniform/mechanical
        self.jitter = np.random.uniform(0.6, 1.3, size=N_POINTS)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.animate)
        self.timer.start(33)  # ~30 FPS - lighter on the GIL so the mic thread stays responsive

        signals.amplitude_changed.connect(self.set_amplitude)
        signals.dock_to_corner.connect(self.set_docked)

    def set_amplitude(self, value: float):
        self.target_amplitude = max(0.0, min(1.0, value))

    def set_docked(self, docked: bool):
        self.docked = docked
        self.update()

    def animate(self):
        # Asymmetric easing: rise fast (snappy response to speech),
        # fall slower (smooth decay instead of jittery cutoffs)
        if self.target_amplitude > self.amplitude:
            self.amplitude += (self.target_amplitude - self.amplitude) * 0.45
        else:
            self.amplitude += (self.target_amplitude - self.amplitude) * 0.12
        self.phase += 0.006  # slow rotation
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        w, h = self.width(), self.height()
        cx, cy = w / 2, h / 2

        base_r = (34 if self.docked else 190)
        R = base_r * (1 + self.amplitude * 0.12)

        # Rotate around Y axis
        a = self.phase
        cos_a, sin_a = math.cos(a), math.sin(a)
        rx = self.px * cos_a - self.pz * sin_a
        rz = self.px * sin_a + self.pz * cos_a
        ry = self.py

        # Slight tilt so it doesn't look flat
        tilt = math.radians(12)
        cos_t, sin_t = math.cos(tilt), math.sin(tilt)
        ry2 = ry * cos_t - rz * sin_t
        rz2 = ry * sin_t + rz * cos_t

        depth = (rz2 + 1) / 2.0  # 0 (far) .. 1 (near)

        sx = cx + rx * R
        sy = cy + ry2 * R

        # Cull points on the far/occluded side of the sphere - they're barely
        # visible anyway and skipping them roughly halves the draw calls
        visible = depth > 0.12
        idxs = np.nonzero(visible)[0]
        # Sort back-to-front so near points draw on top
        idxs = idxs[np.argsort(depth[idxs])]

        pulse_boost = 1.0 + self.amplitude * 0.9

        # Vectorized brightness/alpha/size for all visible points at once
        d_v = depth[idxs]
        edge_factor = np.minimum(1.0, rx[idxs] ** 2 + ry2[idxs] ** 2)
        brightness = (0.15 + 0.85 * d_v) * (0.6 + 0.4 * edge_factor)
        brightness = np.minimum(1.0, brightness * (0.85 + 0.3 * self.amplitude))

        r_arr = (BLUE_DIM[0] + (BLUE[0] - BLUE_DIM[0]) * brightness).astype(int)
        g_arr = (BLUE_DIM[1] + (BLUE[1] - BLUE_DIM[1]) * brightness).astype(int)
        b_arr = (BLUE_DIM[2] + (BLUE[2] - BLUE_DIM[2]) * brightness).astype(int)
        alpha_arr = (60 + 195 * d_v).astype(int)
        size_arr = (0.6 + 1.6 * d_v) * self.jitter[idxs] * pulse_boost
        if self.docked:
            size_arr *= 0.5
        size_arr = np.maximum(1, size_arr).astype(int)

        sx_v, sy_v = sx[idxs].astype(int), sy[idxs].astype(int)

        painter.setPen(Qt.PenStyle.NoPen)
        for i in range(len(idxs)):
            painter.setBrush(QBrush(QColor(int(r_arr[i]), int(g_arr[i]), int(b_arr[i]), int(alpha_arr[i]))))
            painter.drawEllipse(QPoint(int(sx_v[i]), int(sy_v[i])), int(size_arr[i]), int(size_arr[i]))

        # Soft glowing core
        core_r = (10 if self.docked else 22) + self.amplitude * 14
        glow = QColor(*BLUE, 90)
        painter.setBrush(QBrush(glow))
        painter.drawEllipse(QPoint(int(cx), int(cy)), int(core_r), int(core_r))


class SystemStatsBar(QWidget):
    """
    Always-visible system stats bar on the HUD — bottom-left corner.
    Shows CPU, RAM, battery, and Wi-Fi. Updates every 3 seconds.
    Hides automatically when desktop mode is active.
    """

    def __init__(self):
        super().__init__()
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedWidth(320)
        self.setFixedHeight(110)
        self._visible_on_hud = True

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(4)

        header = QLabel("[ SYSTEM ]")
        header.setFont(QFont("Consolas", 9))
        header.setStyleSheet("color: #1E6FAF; letter-spacing: 2px;")
        layout.addWidget(header)

        self.cpu_label    = self._make_label()
        self.ram_label    = self._make_label()
        self.battery_label = self._make_label()
        self.wifi_label   = self._make_label()

        for lbl in [self.cpu_label, self.ram_label,
                    self.battery_label, self.wifi_label]:
            layout.addWidget(lbl)

        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self._refresh)
        self.refresh_timer.start(3000)
        self._refresh()

        signals.desktop_mode.connect(self._on_desktop_mode)

    def _make_label(self):
        lbl = QLabel("—")
        lbl.setFont(QFont("Consolas", 10))
        lbl.setStyleSheet("color: #3CAAFF;")
        return lbl

    def _on_desktop_mode(self, active: bool):
        self.setVisible(not active)

    def _refresh(self):
        try:
            import psutil, socket
            cpu = psutil.cpu_percent(interval=None)
            ram = psutil.virtual_memory()
            ram_used = ram.used / (1024 ** 3)
            ram_total = ram.total / (1024 ** 3)

            self.cpu_label.setText(f"  CPU  {cpu:.0f}%")
            self.cpu_label.setStyleSheet(
                f"color: {'#FF4444' if cpu > 85 else '#FFAA00' if cpu > 60 else '#3CAAFF'};")

            self.ram_label.setText(
                f"  RAM  {ram_used:.1f} / {ram_total:.0f} GB  ({ram.percent:.0f}%)")

            bat = psutil.sensors_battery()
            if bat:
                icon = "⚡" if bat.power_plugged else "🔋"
                pct = round(bat.percent)
                color = "#FF4444" if pct < 15 else "#FFAA00" if pct < 30 else "#3CAAFF"
                self.battery_label.setText(f"  BAT  {icon} {pct}%")
                self.battery_label.setStyleSheet(f"color: {color};")
            else:
                self.battery_label.setText("  BAT  Desktop")
                self.battery_label.setStyleSheet("color: #336699;")

            try:
                hostname = socket.gethostname()
                ip = socket.gethostbyname(hostname)
                self.wifi_label.setText(f"  NET  {ip}")
                self.wifi_label.setStyleSheet("color: #3CAAFF;")
            except Exception:
                self.wifi_label.setText("  NET  Offline")
                self.wifi_label.setStyleSheet("color: #FF4444;")

        except Exception:
            pass

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setBrush(QBrush(QColor(0, 0, 0, 180)))
        painter.setPen(QPen(QColor(30, 111, 175, 180), 1))
        painter.drawRoundedRect(self.rect().adjusted(1, 1, -1, -1), 8, 8)



class MessagePanel(QWidget):
    """Black square panel, blue outline, blue/white text — draggable."""

    def __init__(self):
        super().__init__()
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedWidth(340)
        self.setMinimumHeight(80)
        self.setMaximumHeight(300)
        self._drag_pos = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)

        self.title_label = QLabel("")
        self.title_label.setStyleSheet("color: #3CAAFF; font-weight: bold;")
        self.title_label.setFont(QFont("Consolas", 13))

        self.body_label = QLabel("")
        self.body_label.setStyleSheet("color: white;")
        self.body_label.setFont(QFont("Consolas", 11))
        self.body_label.setWordWrap(True)

        layout.addWidget(self.title_label)
        layout.addWidget(self.body_label)

        self.hide()

        self.auto_hide_timer = QTimer(self)
        self.auto_hide_timer.setSingleShot(True)
        self.auto_hide_timer.timeout.connect(self.hide)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, event):
        if self._drag_pos and event.buttons() == Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_pos)

    def mouseReleaseEvent(self, event):
        self._drag_pos = None

    def show_message(self, title: str, body: str):
        self.title_label.setText(title)
        self.body_label.setText(body)
        self.show()
        self.auto_hide_timer.start(6000)

    def show_live_text(self, title: str, body: str):
        """Shows the panel without auto-hiding — for live dictation display."""
        self.auto_hide_timer.stop()
        self.title_label.setText(title)
        self.body_label.setText(body)
        self.show()

    def reposition_random(self, screen_w: int, screen_h: int):
        """Picks a random spot on screen, avoiding the very edges."""
        import random
        x = random.randint(40, max(41, screen_w - self.width() - 40))
        y = random.randint(80, max(81, screen_h - self.height() - 80))
        self.move(x, y)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(2, 2, -2, -2)
        painter.setBrush(QBrush(QColor(0, 0, 0, 230)))
        painter.setPen(QPen(QColor(*BLUE), 2))
        painter.drawRoundedRect(rect, 10, 10)


class JarvisOverlay(QWidget):
    """Top-level overlay: full black background (fades out when an app is
    opened), hosting the sphere orb + message panel."""

    def __init__(self):
        super().__init__()
        screen = QGuiApplication.primaryScreen().geometry()
        self.setGeometry(screen)

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        self.bg_alpha = 255.0
        self.bg_target = 255.0
        self.docked = False

        self.orb = SphereOrbWidget()
        self.orb.setParent(self)
        self.orb.resize(460, 460)

        self.message_panel = MessagePanel()
        self.message_panel.setParent(self)

        self.stats_bar = SystemStatsBar()
        self.stats_bar.setParent(self)

        signals.dock_to_corner.connect(self.reposition)
        signals.desktop_mode.connect(self.set_desktop_mode)
        signals.show_message.connect(self.message_panel.show_message)
        signals.show_live_text.connect(self.message_panel.show_live_text)
        signals.hide_message.connect(self.message_panel.hide)
        signals.open_hud_panel.connect(self.show_panel)
        signals.close_hud_panels.connect(self.close_all_panels)
        self.reposition(False)

        self.bg_timer = QTimer(self)
        self.bg_timer.timeout.connect(self.animate_bg)
        self.bg_timer.start(33)

        # HUD panels - created on demand, reused after first creation
        self._panels = {}

        global _overlay_instance
        _overlay_instance = self

    def _get_or_create_panel(self, kind: str):
        if kind not in self._panels:
            if kind == "notes":
                self._panels[kind] = NotesHudPanel(self)
            elif kind == "weather":
                self._panels[kind] = WeatherHudPanel(self)
            elif kind == "calendar":
                self._panels[kind] = CalendarHudPanel(self)
            elif kind == "youtube":
                self._panels[kind] = YouTubeHudPanel(self)
            else:
                self._panels[kind] = InfoHudPanel(self, f"JARVIS · {kind.title()}")
        return self._panels[kind]

    def show_panel(self, kind: str, data: str = ""):
        screen = self.geometry()
        panel = self._get_or_create_panel(kind)

        if kind == "notes":
            panel.load_notes()
        elif kind == "weather":
            panel.load_weather()
        elif kind == "calendar":
            panel.load_events()
        elif kind == "youtube":
            panel.load_video(data)
        elif kind == "info":
            panel.set_text(data)

        panel.show_centered(screen.width(), screen.height())

    def close_all_panels(self):
        for panel in self._panels.values():
            panel.hide()

    def set_desktop_mode(self, active: bool):
        # Always fully transparent when desktop mode - never dim the screen
        self.bg_target = 0.0 if active else (0.0 if self.docked else 255.0)
        # Always click-through in desktop mode
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, active or self.docked)
        screen = self.geometry()
        if active:
            self.message_panel.move(screen.width() - 380, 185)
        else:
            self.reposition(self.docked)

    def reposition(self, docked: bool):
        self.docked = docked
        screen = self.geometry()

        if docked:
            self.bg_target = 0.0  # fully transparent - no dimming whatsoever
            self.orb.resize(140, 140)
            self.orb.move(screen.width() - 170, 30)
            self.message_panel.move(screen.width() - 380, 185)
        else:
            self.bg_target = 255.0
            self.orb.resize(460, 460)
            self.orb.move(screen.width() // 2 - 230, screen.height() // 2 - 230)
            self.message_panel.reposition_random(screen.width(), screen.height())

        # Stats bar: bottom-left corner, always
        self.stats_bar.move(20, screen.height() - self.stats_bar.height() - 20)

        # Always click-through when docked so apps are fully usable underneath
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, docked)

    def animate_bg(self):
        self.bg_alpha += (self.bg_target - self.bg_alpha) * 0.08
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(0, 0, 0, int(self.bg_alpha)))


# ---------------------------------------------------------------------------
# Demo driver — simulates TTS speaking + a message popup + docking.
# Replace this block with real calls from your TTS/command modules.
# ---------------------------------------------------------------------------
def _demo(overlay):
    state = {"t": 0}

    def tick():
        state["t"] += 1
        if state["t"] < 300:
            amp = abs(math.sin(state["t"] * 0.2)) * random.uniform(0.6, 1.0)
            signals.amplitude_changed.emit(amp)
        else:
            signals.amplitude_changed.emit(0.0)

        if state["t"] == 30:
            signals.show_message.emit("JARVIS", get_greeting_line())
        if state["t"] == 190:  # ~3 seconds at 60fps
            signals.dock_to_corner.emit(True)
            signals.show_message.emit("JARVIS", "Opening Google Chrome.")
        if state["t"] == 490:
            signals.dock_to_corner.emit(False)

    timer = QTimer()
    timer.timeout.connect(tick)
    timer.start(16)
    overlay._demo_timer = timer


def create_overlay():
    """
    Creates the QApplication + overlay window without running the event
    loop or the demo. Call this from your own script, then run app.exec()
    yourself once your background voice thread is started.
    """
    app = QApplication(sys.argv)
    overlay = JarvisOverlay()
    overlay.show()
    return app, overlay


def main():
    app, overlay = create_overlay()
    _demo(overlay)  # remove this line once wired to real TTS/commands
    sys.exit(app.exec())


if __name__ == "__main__":
    main()


# ---------------------------------------------------------------------------
# HUD App Panels - floating draggable panels rendered on the black HUD screen
# ---------------------------------------------------------------------------

class HudPanel(QWidget):
    """
    Base draggable panel with black background and blue outline.
    All HUD app panels inherit from this.
    """
    def __init__(self, parent, title: str, w: int = 420, h: int = 320):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(w, h)
        self._drag_pos = None
        self._title = title

        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(16, 14, 16, 14)
        self._layout.setSpacing(8)

        # Title bar
        title_label = QLabel(title)
        title_label.setStyleSheet("color: #3CAAFF; font-weight: bold;")
        title_label.setFont(QFont("Consolas", 13))
        self._layout.addWidget(title_label)

        # Close hint
        hint = QLabel("[ drag to move · say \"close panel\" to dismiss ]")
        hint.setStyleSheet("color: #336699; font-size: 9px;")
        self._layout.addWidget(hint)

        self.hide()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setBrush(QBrush(QColor(0, 0, 0, 230)))
        painter.setPen(QPen(QColor(*BLUE), 2))
        painter.drawRoundedRect(self.rect().adjusted(1, 1, -1, -1), 10, 10)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, event):
        if self._drag_pos and event.buttons() == Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_pos)

    def mouseReleaseEvent(self, event):
        self._drag_pos = None

    def show_centered(self, screen_w: int, screen_h: int):
        self.move(screen_w // 2 - self.width() // 2,
                  screen_h // 2 - self.height() // 2)
        self.show()
        self.raise_()


class NotesHudPanel(HudPanel):
    """Shows saved JARVIS notes as a scrollable list."""

    def __init__(self, parent):
        super().__init__(parent, "JARVIS · Notes", w=420, h=360)
        from PyQt6.QtWidgets import QScrollArea, QFrame
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet(
            "QScrollArea { background: transparent; border: none; }"
            "QScrollBar:vertical { background: #111; width: 6px; }"
            "QScrollBar::handle:vertical { background: #3CAAFF; }"
        )
        self.content = QLabel()
        self.content.setWordWrap(True)
        self.content.setStyleSheet("color: white; padding: 4px;")
        self.content.setFont(QFont("Consolas", 10))
        self.content.setAlignment(Qt.AlignmentFlag.AlignTop)
        scroll.setWidget(self.content)
        self._layout.addWidget(scroll)

    def load_notes(self):
        try:
            import sys, os
            sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            from memory import _load
            data = _load()
            notes = data.get("notes", [])
            if not notes:
                self.content.setText("No notes saved yet.")
            else:
                lines = []
                for i, n in enumerate(reversed(notes), 1):
                    ts = n.get("saved_at", "")[:16].replace("T", " ")
                    lines.append(f"[{i}] {n['text']}\n    {ts}")
                self.content.setText("\n\n".join(lines))
        except Exception as e:
            self.content.setText(f"Error loading notes: {e}")


class WeatherHudPanel(HudPanel):
    """Shows current weather + 3-day forecast."""

    def __init__(self, parent):
        super().__init__(parent, "JARVIS · Weather", w=400, h=260)
        self.body = QLabel("Loading...")
        self.body.setWordWrap(True)
        self.body.setStyleSheet("color: white;")
        self.body.setFont(QFont("Consolas", 11))
        self.body.setAlignment(Qt.AlignmentFlag.AlignTop)
        self._layout.addWidget(self.body)

    def load_weather(self):
        def _fetch():
            try:
                import sys, os
                sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                from weather import get_weather, get_forecast
                text = get_weather() + "\n\n" + get_forecast()
                self.body.setText(text)
            except Exception as e:
                self.body.setText(f"Error: {e}")
        import threading
        threading.Thread(target=_fetch, daemon=True).start()


class CalendarHudPanel(HudPanel):
    """Shows upcoming calendar events."""

    def __init__(self, parent):
        super().__init__(parent, "JARVIS · Calendar", w=420, h=300)
        self.body = QLabel("Loading...")
        self.body.setWordWrap(True)
        self.body.setStyleSheet("color: white;")
        self.body.setFont(QFont("Consolas", 11))
        self.body.setAlignment(Qt.AlignmentFlag.AlignTop)
        self._layout.addWidget(self.body)

    def load_events(self):
        def _fetch():
            try:
                import sys, os
                sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                from calendar_client import get_upcoming_events
                events = get_upcoming_events(8)
                if not events:
                    self.body.setText("No upcoming events.")
                else:
                    lines = [f"• {e['start'][:16].replace('T',' ')}  {e['summary']}"
                             for e in events]
                    self.body.setText("\n".join(lines))
            except Exception as e:
                self.body.setText(f"Error: {e}")
        import threading
        threading.Thread(target=_fetch, daemon=True).start()


class YouTubeHudPanel(HudPanel):
    """Embeds a YouTube video in a HUD panel via embedded iframe in a web view."""

    def __init__(self, parent):
        super().__init__(parent, "JARVIS · Video", w=640, h=400)
        try:
            from PyQt6.QtWebEngineWidgets import QWebEngineView
            self.web = QWebEngineView()
            self.web.setFixedSize(608, 342)
            self._layout.addWidget(self.web)
            self._has_web = True
        except ImportError:
            fallback = QLabel("PyQtWebEngine not installed.\nVideo opens in browser instead.")
            fallback.setStyleSheet("color: #888;")
            fallback.setFont(QFont("Consolas", 10))
            self._layout.addWidget(fallback)
            self._has_web = False

    def load_video(self, query: str):
        if not self._has_web:
            import webbrowser, urllib.parse
            webbrowser.open(f"https://www.youtube.com/results?search_query={urllib.parse.quote(query)}")
            return
        import urllib.parse
        # Use YouTube's embed search — opens first result inline
        encoded = urllib.parse.quote(query)
        html = f"""
        <html><body style="margin:0;background:#000;">
        <iframe width="608" height="342"
            src="https://www.youtube.com/embed?listType=search&list={encoded}&autoplay=1"
            frameborder="0" allowfullscreen allow="autoplay"></iframe>
        </body></html>"""
        self.web.setHtml(html)


class InfoHudPanel(HudPanel):
    """Generic info panel for system info, email summary, etc."""

    def __init__(self, parent, title="JARVIS · Info"):
        super().__init__(parent, title, w=420, h=280)
        self.body = QLabel("")
        self.body.setWordWrap(True)
        self.body.setStyleSheet("color: white;")
        self.body.setFont(QFont("Consolas", 11))
        self.body.setAlignment(Qt.AlignmentFlag.AlignTop)
        self._layout.addWidget(self.body)

    def set_text(self, text: str):
        self.body.setText(text)


# ---------------------------------------------------------------------------
# Add HUD panel management to JarvisOverlay
# ---------------------------------------------------------------------------

_overlay_instance = None  # set when JarvisOverlay is created


def show_hud_panel(panel_type: str, data: str = ""):
    """Called from the command router to show a HUD panel."""
    if _overlay_instance:
        _overlay_instance.show_panel(panel_type, data)


