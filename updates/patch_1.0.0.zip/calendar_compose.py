"""
JARVIS Voice Calendar Composer
-----------------------------------
Guided voice flow for adding a calendar event: asks what it's called,
then when, parses natural spoken time ("tomorrow at 3pm", "next Friday
at noon") into an actual date, confirms, then creates it.
"""

import dateparser
from stt import listen_and_transcribe
from tts import speak
from calendar_client import create_event, get_upcoming_events


def compose_and_create_event() -> str:
    speak("What's the event called?")
    title = listen_and_transcribe(seconds=4)
    if not title:
        return "I didn't catch that, sir. Cancelling."

    speak("When is it? Say something like 'tomorrow at 3pm'.")
    when_text = listen_and_transcribe(seconds=4)
    if not when_text:
        return "I didn't catch a time, sir. Cancelling."

    parsed_dt = dateparser.parse(
        when_text, settings={"PREFER_DATES_FROM": "future"}
    )

    if not parsed_dt:
        return f"I couldn't understand '{when_text}' as a date or time, sir. Cancelling."

    friendly_time = parsed_dt.strftime("%A, %B %d at %I:%M %p")
    speak(f"Adding {title} on {friendly_time}. Should I confirm it?")
    confirm = listen_and_transcribe(seconds=3).lower()
    if not any(w in confirm for w in ["yes", "yeah", "correct", "confirm", "add"]):
        return "Okay, I won't add that."

    return create_event(summary=title, start_dt=parsed_dt)


def check_calendar(count: int = 3) -> str:
    events = get_upcoming_events(count=count)
    if not events:
        return "You have nothing coming up, sir."
    lines = [f"{e['summary']} on {e['start']}" for e in events]
    return f"You have {len(events)} upcoming events. " + "; ".join(lines)
