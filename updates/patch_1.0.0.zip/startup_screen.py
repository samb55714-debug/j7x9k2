"""
JARVIS Startup Screen
----------------------
Shows a mode selection GUI before anything else loads.
User picks Desktop Mode or HUD Mode, then JARVIS boots accordingly.
"""

import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QObject
from PyQt6.QtGui import QFont, QPainter, QColor, QBrush

BLUE = "#3CAAFF"
BLUE_DIM = "#1a4a6e"
BG = "#000000"


class StartupSignals(QObject):
    mode_selected = pyqtSignal(str)  # "desktop" or "hud"

startup_signals = StartupSignals()


class StartupScreen(QWidget):
    def __init__(self):
        super().__init__()
        self.selected_mode = None
        self._countdown = 15  # must be set before _build_ui uses it
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(560, 400)
        self._center()
        self._build_ui()

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(1000)

    def _center(self):
        from PyQt6.QtWidgets import QApplication
        screen = QApplication.primaryScreen().geometry()
        self.move(
            screen.width() // 2 - self.width() // 2,
            screen.height() // 2 - self.height() // 2
        )

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        card = QWidget()
        card.setObjectName("card")
        card.setStyleSheet(f"""
            QWidget#card {{
                background-color: #060606;
                border: 2px solid {BLUE};
                border-radius: 16px;
            }}
        """)

        layout = QVBoxLayout(card)
        layout.setContentsMargins(40, 36, 40, 32)
        layout.setSpacing(0)

        # JARVIS logo text
        logo = QLabel("J.A.R.V.I.S")
        logo.setFont(QFont("Consolas", 28, QFont.Weight.Bold))
        logo.setStyleSheet(f"color: {BLUE}; border: none; letter-spacing: 8px;")
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(logo)

        subtitle = QLabel("Just A Rather Very Intelligent System")
        subtitle.setFont(QFont("Consolas", 9))
        subtitle.setStyleSheet("color: #336688; border: none;")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)

        layout.addSpacing(32)

        question = QLabel("Select startup mode:")
        question.setFont(QFont("Consolas", 12))
        question.setStyleSheet("color: #aaaaaa; border: none;")
        question.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(question)

        layout.addSpacing(20)

        # Mode buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(20)

        self.hud_btn = self._make_btn(
            "⬛  HUD Mode",
            "Full black screen\nOrb centered\nFull immersion",
            primary=True
        )
        self.hud_btn.clicked.connect(lambda: self._select("hud"))

        self.desktop_btn = self._make_btn(
            "🖥️  Desktop Mode",
            "Your desktop visible\nOrb in top-right corner\nUse PC normally",
            primary=False
        )
        self.desktop_btn.clicked.connect(lambda: self._select("desktop"))

        btn_row.addWidget(self.hud_btn)
        btn_row.addWidget(self.desktop_btn)
        layout.addLayout(btn_row)

        layout.addSpacing(24)

        # Countdown
        self.countdown_label = QLabel(f"Auto-selecting HUD mode in {self._countdown}s...")
        self.countdown_label.setFont(QFont("Consolas", 9))
        self.countdown_label.setStyleSheet("color: #444; border: none;")
        self.countdown_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.countdown_label)

        outer.addWidget(card)

    def _make_btn(self, title: str, desc: str, primary: bool) -> QPushButton:
        btn = QPushButton()
        btn.setFixedSize(210, 120)
        border_color = BLUE if primary else "#336688"
        bg_color = "#0a1a2a" if primary else "#080808"
        hover_bg = "#0d2a45" if primary else "#0a1a2a"
        title_color = BLUE if primary else "#6699bb"

        btn.setStyleSheet(f"""
            QPushButton {{
                background: {bg_color};
                border: 2px solid {border_color};
                border-radius: 10px;
                color: {title_color};
                font-family: Consolas;
                font-size: 13px;
                font-weight: bold;
                padding: 10px;
                text-align: center;
            }}
            QPushButton:hover {{
                background: {hover_bg};
                border-color: {BLUE};
                color: {BLUE};
            }}
            QPushButton:pressed {{
                background: #1a3a5c;
            }}
        """)

        # Multi-line text via HTML
        btn.setText(f"{title}\n\n{desc}")
        btn.setFont(QFont("Consolas", 10))
        return btn

    def _tick(self):
        self._countdown -= 1
        self.countdown_label.setText(f"Auto-selecting HUD mode in {self._countdown}s...")
        if self._countdown <= 0:
            self._select("hud")

    def _select(self, mode: str):
        self._timer.stop()
        self.selected_mode = mode
        # Flash effect before closing
        self.countdown_label.setText(
            f"{'HUD Mode' if mode == 'hud' else 'Desktop Mode'} selected. Booting JARVIS..."
        )
        self.countdown_label.setStyleSheet(f"color: {BLUE}; border: none;")
        QTimer.singleShot(800, lambda: (self.hide(), startup_signals.mode_selected.emit(mode)))

    def paintEvent(self, event):
        # Transparent background
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(0, 0, 0, 0))


def run_startup_screen() -> str:
    """
    Shows the startup screen and blocks until the user picks a mode.
    Returns 'hud' or 'desktop'.
    """
    result = [None]

    # Use existing QApplication if one exists, otherwise create one
    app = QApplication.instance()
    created_app = False
    if app is None:
        app = QApplication(sys.argv)
        created_app = True

    screen = StartupScreen()

    def on_mode(mode):
        result[0] = mode
        app.quit()

    startup_signals.mode_selected.connect(on_mode)
    screen.show()
    app.exec()

    return result[0] or "hud"


if __name__ == "__main__":
    mode = run_startup_screen()
    print(f"Selected: {mode}")
