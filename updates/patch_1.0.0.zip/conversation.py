"""
JARVIS Natural Conversation Module
Uses Ollama (local LLM) for natural back-and-forth conversation.
Falls back to a polite "I don't know" if Ollama isn't running.
"""
import requests

JARVIS_PERSONA = """You are JARVIS, Tony Stark's AI assistant. You are calm, 
precise, slightly witty, and always helpful. You speak in short, clear sentences 
suitable for voice output (no bullet points, no markdown, no lists). 
Keep responses under 3 sentences unless detail is genuinely needed.
Address the user as 'sir' occasionally but not every response."""

_history = []  # keeps last few exchanges for context


def chat(user_text: str) -> str:
    global _history
    _history.append({"role": "user", "content": user_text})
    
    # Keep history to last 6 exchanges to avoid slow responses
    if len(_history) > 12:
        _history = _history[-12:]

    # Build prompt with history
    history_text = "\n".join(
        f"{'User' if m['role']=='user' else 'JARVIS'}: {m['content']}"
        for m in _history[-6:]
    )
    prompt = f"{JARVIS_PERSONA}\n\nConversation:\n{history_text}\nJARVIS:"

    try:
        r = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": "phi3", "prompt": prompt, "stream": False,
                  "options": {"temperature": 0.7, "num_predict": 80}},
            timeout=8)
        if r.status_code == 200:
            response = r.json().get("response", "").strip()
            _history.append({"role": "assistant", "content": response})
            return response
    except Exception:
        pass

    _history.pop()  # remove the user message if we failed
    return "I'm afraid I don't have a good answer for that right now, sir."


def clear_history():
    global _history
    _history = []


if __name__ == "__main__":
    print("JARVIS conversation test (type 'quit' to exit):")
    while True:
        text = input("You: ")
        if text.lower() == "quit":
            break
        print(f"JARVIS: {chat(text)}")
