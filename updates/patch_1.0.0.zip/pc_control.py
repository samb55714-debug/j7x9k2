"""
JARVIS PC Control Module
Shutdown, restart, lock, sleep, log off.
"""
import subprocess
import ctypes

def shutdown(delay_seconds: int = 10) -> str:
    subprocess.run(f"shutdown /s /t {delay_seconds}", shell=True)
    return f"Shutting down in {delay_seconds} seconds, sir."

def restart(delay_seconds: int = 10) -> str:
    subprocess.run(f"shutdown /r /t {delay_seconds}", shell=True)
    return f"Restarting in {delay_seconds} seconds, sir."

def cancel_shutdown() -> str:
    subprocess.run("shutdown /a", shell=True)
    return "Shutdown cancelled, sir."

def lock() -> str:
    ctypes.windll.user32.LockWorkStation()
    return "Locking your PC, sir."

def sleep() -> str:
    subprocess.run("rundll32.exe powrprof.dll,SetSuspendState 0,1,0", shell=True)
    return "Going to sleep, sir."

def log_off() -> str:
    subprocess.run("shutdown /l", shell=True)
    return "Logging off, sir."

if __name__ == "__main__":
    print("PC control module loaded.")
    print("Available: shutdown, restart, lock, sleep, log_off, cancel_shutdown")
