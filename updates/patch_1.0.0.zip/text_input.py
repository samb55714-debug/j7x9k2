"""
JARVIS Text Input & Command Palette v2
- Updated with all current commands
- Organized into labeled sections
- Commands with search box append typed text automatically
"""

import sys
import threading
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QLineEdit, QListWidget, QListWidgetItem, QLabel
)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont, QColor

BLUE = "#3CAAFF"

# Format: (display label, command string)
# Commands ending with a space will auto-append the search box text
# Section headers start with "---"
QUICK_COMMANDS = [
    # ── TIME & INFO ──────────────────────────────────────────────
    ("── ⏱  Time & Info ──────────────────────",    None),
    ("🕐  What time is it",                          "what time is it"),
    ("📅  What's the date",                          "what's the date"),
    ("🌤  What's the weather",                       "what's the weather"),
    ("💻  System info",                              "system info"),

    # ── JARVIS MODES ─────────────────────────────────────────────
    ("── 🖥  JARVIS Modes ─────────────────────",   None),
    ("🖥️  Open Desktop",                             "open desktop"),
    ("⬛  Open HUD",                                 "open hud"),
    ("🌙  Goodnight JARVIS",                         "goodnight jarvis"),
    ("⏰  Wake Up JARVIS",                           "wake up jarvis"),

    # ── APPS ─────────────────────────────────────────────────────
    ("── 📱  Open Apps ───────────────────────",    None),
    ("🌐  Open Chrome",                              "open chrome"),
    ("🎮  Open Discord",                             "open discord"),
    ("🎵  Open Spotify",                             "open spotify"),
    ("🎮  Open Steam",                               "open steam"),
    ("📝  Open Notepad",                             "open notepad"),
    ("🧮  Open Calculator",                          "open calculator"),
    ("📁  Open File Explorer",                       "open file explorer"),
    ("⚙️  Open Settings",                            "open settings"),
    ("📊  Open Task Manager",                        "open task manager"),
    ("🎨  Open Paint",                               "open paint"),
    ("🎬  Open OBS",                                 "open obs"),
    ("🔧  Open VS Code",                             "open vs code"),
    ("🎮  Open Roblox",                              "open roblox"),
    ("🎮  Open Minecraft",                           "open minecraft"),
    ("📱  Open app: ",                               "open "),

    # ── BROWSER ──────────────────────────────────────────────────
    ("── 🌐  Browser ─────────────────────────",    None),
    ("➕  New Tab",                                  "open a new tab"),
    ("❌  Close Tab",                                "close tab"),
    ("⏭  Next Tab",                                  "next tab"),
    ("⏮  Previous Tab",                             "previous tab"),
    ("🔙  Go Back",                                  "go back"),
    ("🔜  Go Forward",                               "go forward"),
    ("🔄  Refresh Page",                             "refresh"),
    ("🔍  Search Google: ",                          "search google for "),
    ("▶️  Search YouTube: ",                         "search youtube for "),
    ("🌐  Go to website: ",                          "navigate to "),
    ("🔍  Click First Result",                       "click first result"),
    ("➕  Zoom In",                                  "zoom in"),
    ("➖  Zoom Out",                                 "zoom out"),

    # ── EMAIL ────────────────────────────────────────────────────
    ("── 📧  Email ───────────────────────────",    None),
    ("📬  Check Email",                              "check my email"),
    ("✉️  Send Email",                               "send an email"),

    # ── CALENDAR ─────────────────────────────────────────────────
    ("── 📆  Calendar ────────────────────────",    None),
    ("📆  Check Calendar",                           "check my calendar"),
    ("➕  Add Event",                                "add an event"),

    # ── TIMERS & REMINDERS ───────────────────────────────────────
    ("── ⏰  Timers & Reminders ───────────────",   None),
    ("⏱  5 Minute Timer",                           "set a timer for 5 minutes"),
    ("⏱  10 Minute Timer",                          "set a timer for 10 minutes"),
    ("⏱  30 Minute Timer",                          "set a timer for 30 minutes"),
    ("⏱  Custom Timer: ",                           "set a timer for "),
    ("🔔  Remind me: ",                             "remind me to "),
    ("⏰  Set Alarm: ",                             "set an alarm for "),
    ("📋  List Timers",                              "what timers do i have"),
    ("❌  Cancel Timer",                             "cancel my timer"),

    # ── NOTES & MEMORY ───────────────────────────────────────────
    ("── 📝  Notes & Memory ──────────────────",    None),
    ("📝  Add Note: ",                              "make a note: "),
    ("📋  Read Notes",                               "what are my notes"),
    ("🗑  Delete Note: ",                            "delete my note about "),
    ("🧠  What do you remember",                    "what do you remember"),
    ("💾  Remember that: ",                         "remember that "),

    # ── WINDOW CONTROL ───────────────────────────────────────────
    ("── 🪟  Window Control ───────────────────",   None),
    ("🔄  Switch Window",                            "switch window"),
    ("❌  Close Window",                             "close window"),
    ("🖥  Show Desktop",                             "show desktop"),
    ("🔽  Scroll Down",                              "scroll down"),
    ("🔼  Scroll Up",                                "scroll up"),

    # ── KEYBOARD & MOUSE ─────────────────────────────────────────
    ("── ⌨️  Keyboard & Mouse ─────────────────",  None),
    ("📋  Copy",                                     "copy"),
    ("📋  Paste",                                    "paste"),
    ("⌨️  Type: ",                                  "type "),
    ("📸  Screenshot",                               "take a screenshot"),
    ("🎬  Clip That (Medal)",                        "clip that"),

    # ── PC CONTROL ───────────────────────────────────────────────
    ("── 💻  PC Control ──────────────────────",    None),
    ("🔒  Lock Computer",                            "lock my computer"),
    ("😴  Sleep Computer",                           "sleep computer"),
    ("🔁  Restart Computer",                         "restart"),
    ("⏻  Shut Down",                                "shut down"),

    # ── DISCORD ──────────────────────────────────────────────────
    ("── 💬  Discord ─────────────────────────",    None),
    ("💬  Send Discord Message",                     "send a discord message"),
    ("📖  Check Discord",                            "check discord"),

    # ── GAMES ────────────────────────────────────────────────────
    ("── 🎮  Games ───────────────────────────",    None),
    ("🎯  Play Trivia",                              "play trivia"),
    ("❓  Play 20 Questions",                        "play 20 questions"),
    ("🔢  Guess My Number",                          "guess my number"),
    ("🧩  Play Riddles",                             "play riddles"),
    ("🛑  Stop Game",                                "stop game"),

    # ── CONVERSATION ─────────────────────────────────────────────
    ("── 💭  Chat with JARVIS ────────────────",    None),
    ("😄  Tell me a joke",                           "tell me a joke"),
    ("❓  Ask JARVIS anything: ",                    ""),
    ("🔄  Reset Conversation",                       "reset conversation"),
]


class CommandPalette(QWidget):

    def __init__(self, on_command):
        super().__init__()
        self.on_command = on_command
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(520, 600)
        self._build_ui()

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        card = QWidget()
        card.setObjectName("card")
        card.setStyleSheet("""
            QWidget#card {
                background: #080808;
                border: 2px solid #3CAAFF;
                border-radius: 14px;
            }
        """)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 16, 16, 14)
        layout.setSpacing(10)

        # Title
        title = QLabel("⚡  JARVIS Command Palette")
        title.setFont(QFont("Consolas", 12, QFont.Weight.Bold))
        title.setStyleSheet("color: #3CAAFF; border: none;")
        layout.addWidget(title)

        # Search box
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search commands or type anything...")
        self.search.setFont(QFont("Consolas", 11))
        self.search.setStyleSheet("""
            QLineEdit {
                background: #111;
                border: 1px solid #3CAAFF;
                border-radius: 7px;
                color: white;
                padding: 8px 12px;
            }
        """)
        self.search.textChanged.connect(self._filter)
        self.search.returnPressed.connect(self._run_current)
        layout.addWidget(self.search)

        # Command list
        self.lst = QListWidget()
        self.lst.setFont(QFont("Consolas", 10))
        self.lst.setStyleSheet("""
            QListWidget {
                background: #050505;
                border: 1px solid #1a1a1a;
                border-radius: 7px;
                color: white;
                outline: none;
            }
            QListWidget::item {
                padding: 6px 12px;
                border-bottom: 1px solid #0f0f0f;
            }
            QListWidget::item:selected {
                background: #0d2a45;
                color: #3CAAFF;
            }
            QListWidget::item:hover { background: #0a0a0a; }
        """)
        self.lst.itemDoubleClicked.connect(self._submit_item)
        self._populate()
        layout.addWidget(self.lst)

        # Hint
        hint = QLabel("Enter / double-click to run  ·  Esc to close  ·  ↑↓ to navigate")
        hint.setStyleSheet("color: #444; font-size: 9px; border: none;")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(hint)

        outer.addWidget(card)

    def _populate(self, f=""):
        self.lst.clear()
        first_selectable = None

        for label, cmd in QUICK_COMMANDS:
            # Section header
            if cmd is None:
                if f:  # hide section headers when filtering
                    continue
                item = QListWidgetItem(label)
                item.setFlags(Qt.ItemFlag.NoItemFlags)  # not selectable
                item.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
                item.setForeground(QColor("#336688"))
                self.lst.addItem(item)
                continue

            # Filter
            if f and f.lower() not in label.lower() and f.lower() not in cmd.lower():
                continue

            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, cmd)
            self.lst.addItem(item)
            if first_selectable is None:
                first_selectable = self.lst.count() - 1

        if first_selectable is not None:
            self.lst.setCurrentRow(first_selectable)

    def _filter(self, text):
        self._populate(text)

    def _submit_item(self, item):
        if not item:
            return
        if not (item.flags() & Qt.ItemFlag.ItemIsEnabled):
            return  # section header
        cmd = item.data(Qt.ItemDataRole.UserRole)
        if cmd is None:
            return
        search_text = self.search.text().strip()
        # If command ends with space, it's a template — append search text
        if cmd.endswith(" ") and search_text:
            cmd = cmd + search_text
        elif not cmd and search_text:
            cmd = search_text
        if cmd.strip():
            self.hide()
            threading.Thread(target=self.on_command, args=(cmd.strip(),), daemon=True).start()

    def _run_current(self):
        text = self.search.text().strip()
        item = self.lst.currentItem()
        if item and (item.flags() & Qt.ItemFlag.ItemIsEnabled):
            self._submit_item(item)
        elif text:
            self.hide()
            threading.Thread(target=self.on_command, args=(text,), daemon=True).start()

    def keyPressEvent(self, event):
        key = event.key()
        if key == Qt.Key.Key_Escape:
            self.hide()
        elif key == Qt.Key.Key_Down:
            self._move_selection(1)
        elif key == Qt.Key.Key_Up:
            self._move_selection(-1)
        else:
            super().keyPressEvent(event)

    def _move_selection(self, direction: int):
        """Navigate list, skipping section headers."""
        current = self.lst.currentRow()
        total = self.lst.count()
        new_row = current + direction
        while 0 <= new_row < total:
            item = self.lst.item(new_row)
            if item and (item.flags() & Qt.ItemFlag.ItemIsEnabled):
                self.lst.setCurrentRow(new_row)
                return
            new_row += direction

    def show_palette(self):
        self.search.clear()
        self._populate()
        screen = QApplication.primaryScreen().geometry()
        self.move(
            screen.width() // 2 - self.width() // 2,
            screen.height() // 2 - self.height() // 2
        )
        self.show()
        self.raise_()
        self.activateWindow()
        self.search.setFocus()


def install_global_hotkey(palette: CommandPalette):
    try:
        from pynput import keyboard as kb
        pressed = set()
        TRIGGER = {kb.Key.shift, kb.Key.shift_r, kb.Key.ctrl_r}

        def on_press(key):
            pressed.add(key)
            if TRIGGER.issubset(pressed):
                QTimer.singleShot(0, palette.show_palette)

        def on_release(key):
            pressed.discard(key)

        listener = kb.Listener(on_press=on_press, on_release=on_release)
        listener.daemon = True
        listener.start()
        print("[palette] Hotkey: Left Shift + Right Shift + Right Ctrl")
    except ImportError:
        print("[palette] Run: pip install pynput  to enable the hotkey")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    def _test(cmd): print(f"Command: {cmd}")
    p = CommandPalette(on_command=_test)
    install_global_hotkey(p)
    p.show_palette()
    sys.exit(app.exec())
