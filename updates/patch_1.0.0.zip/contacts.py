"""
JARVIS Contacts Module
--------------------------
A simple name -> email address lookup, so you can say "email John" instead
of trying to dictate an email address out loud (which speech-to-text
handles poorly - "at" vs "@", "dot" vs ".", etc).

Edit contacts.json directly to add people. It's created automatically
with an example entry the first time you run anything that needs it.
"""

import json
import os
import re

CONTACTS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "contacts.json")


def _ensure_file_exists():
    if not os.path.exists(CONTACTS_FILE):
        example = {"example person": "example@gmail.com"}
        with open(CONTACTS_FILE, "w") as f:
            json.dump(example, f, indent=2)


def load_contacts() -> dict:
    _ensure_file_exists()
    with open(CONTACTS_FILE, "r") as f:
        return json.load(f)


def lookup_contact(spoken_name: str) -> str | None:
    """Case-insensitive lookup. Returns email or None if not found."""
    contacts = load_contacts()
    spoken_name = spoken_name.lower().strip()
    for name, email in contacts.items():
        if name.lower() == spoken_name:
            return email
    return None


def parse_spoken_email(spoken_text: str) -> str:
    """
    Best-effort fallback for when someone dictates an email address
    directly instead of a contact name, e.g.
    "john dot smith at gmail dot com" -> "john.smith@gmail.com"
    Not perfectly reliable - contacts.json is the recommended path.
    """
    text = spoken_text.lower().strip()
    text = re.sub(r"\s+at\s+", "@", text)
    text = re.sub(r"\s+dot\s+", ".", text)
    text = text.replace(" ", "")
    return text


if __name__ == "__main__":
    contacts = load_contacts()
    print("Current contacts:")
    for name, email in contacts.items():
        print(f"  {name} -> {email}")
    print(f"\nEdit {CONTACTS_FILE} to add more.")
