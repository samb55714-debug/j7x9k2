"""
JARVIS Sleep Mode
------------------
When you say "Goodnight JARVIS", JARVIS goes quiet and only listens
for "Wake up JARVIS" to resume normal operation.
"""

import threading

_sleeping = False
_sleep_lock = threading.Lock()

SLEEP_PHRASES = ["goodnight jarvis", "good night jarvis", "go to sleep jarvis",
                 "sleep jarvis", "jarvis go to sleep"]
WAKE_PHRASES = ["wake up jarvis", "wake up, jarvis", "jarvis wake up",
                "good morning jarvis", "rise and shine jarvis"]


def is_sleeping() -> bool:
    with _sleep_lock:
        return _sleeping


def set_sleeping(val: bool):
    global _sleeping
    with _sleep_lock:
        _sleeping = val


def check_sleep_command(text: str) -> bool:
    """Returns True if this text should trigger sleep mode."""
    return any(p in text.lower() for p in SLEEP_PHRASES)


def check_wake_command(text: str) -> bool:
    """Returns True if this text should wake JARVIS from sleep."""
    return any(p in text.lower() for p in WAKE_PHRASES)
