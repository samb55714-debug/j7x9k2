"""
JARVIS Mic Diagnostic
Run this FIRST to find your mic level and best device index.
"""
import sounddevice as sd
import numpy as np
import time

print("=== Available audio input devices ===")
devices = sd.query_devices()
for i, d in enumerate(devices):
    if d['max_input_channels'] > 0:
        print(f"  [{i}] {d['name']}")

print("\n=== Recording 3 seconds from default mic ===")
print("Speak normally while recording...\n")

duration = 3
audio = sd.rec(int(duration * 16000), samplerate=16000,
               channels=1, dtype='float32')
sd.wait()
audio = audio.flatten()

peak = float(np.max(np.abs(audio)))
rms = float(np.sqrt(np.mean(audio**2)))
print(f"Peak amplitude : {peak:.4f}  (want > 0.1)")
print(f"RMS amplitude  : {rms:.4f}  (want > 0.02)")
print()

if peak < 0.05:
    print("⚠ MIC IS VERY QUIET — likely cause of bad STT")
    print("  Fix: Go to Windows Sound Settings > Input > your mic > increase volume to 100%")
    print("  Also check: Windows Privacy Settings > Microphone > allow desktop apps")
elif peak < 0.15:
    print("⚠ Mic is a bit quiet — STT may struggle with commands")
    print("  Recommended: raise mic volume in Windows Sound Settings")
else:
    print("✓ Mic level looks good")

print(f"\nRecommended SPEECH_THRESHOLD for your mic: {max(0.01, rms * 0.3):.4f}")
print(f"Recommended SILENCE_THRESHOLD for your mic: {max(0.008, rms * 0.2):.4f}")
