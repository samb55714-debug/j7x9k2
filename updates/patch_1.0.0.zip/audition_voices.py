"""
JARVIS Voice Auditioner
--------------------------
Generates a short sample clip from EVERY available voice in the model,
saved as separate files, so you can just listen through them and pick
the one that actually sounds right - rather than trusting speaker ID
labels, which are known to be unreliable/mismatched for this model
(see https://github.com/coqui-ai/TTS/issues/2258).

Usage:
    python audition_voices.py

Then open the "voice_samples" folder it creates and play through the
files. Once you find one you like, note its filename (the speaker ID)
and tell me - I'll set it as the default in tts.py.

Takes a few minutes since it's synthesizing 100+ short clips.
"""

import os
from TTS.api import TTS

OUTPUT_DIR = "voice_samples"
SAMPLE_TEXT = "Good evening, sir. All systems are online."


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("Loading model...")
    engine = TTS(model_name="tts_models/en/vctk/vits", progress_bar=False, gpu=False)

    speakers = engine.speakers
    print(f"Found {len(speakers)} voices. Generating samples...\n")

    for i, spk in enumerate(speakers, 1):
        out_path = os.path.join(OUTPUT_DIR, f"{spk}.wav")
        if os.path.exists(out_path):
            continue  # skip if already generated (lets you resume if interrupted)
        try:
            engine.tts_to_file(text=SAMPLE_TEXT, speaker=spk, file_path=out_path)
            print(f"[{i}/{len(speakers)}] Generated {spk}.wav")
        except Exception as e:
            print(f"[{i}/{len(speakers)}] Failed on {spk}: {e}")

    print(f"\nDone. Open the '{OUTPUT_DIR}' folder and listen through them.")
    print("Once you find one you like, tell me the filename (e.g. 'p245') and")
    print("I'll set it as JARVIS's default voice.")


if __name__ == "__main__":
    main()
