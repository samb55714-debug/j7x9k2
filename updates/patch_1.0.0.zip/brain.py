"""
JARVIS Brain v2 - upgraded personality + long-term memory
"""

import requests
import json
import re
import os
from datetime import datetime

OLLAMA_URL = "http://localhost:11434/api/chat"
MODEL = "phi3"
MAX_HISTORY = 30
MEMORY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "jarvis_memory.json")

SYSTEM_PROMPT = """You are JARVIS - Just A Rather Very Intelligent System, modeled after the AI from Iron Man.

PERSONALITY:
- Calm, precise, highly intelligent, occasionally dry British wit
- Always address the user as "sir" 
- Never sycophantic or overly enthusiastic - measured and professional
- Subtly warm underneath the professional exterior
- Occasionally makes understated observations or dry remarks
- Sounds like Paul Bettany's JARVIS - not robotic, genuinely intelligent

RESPONSE RULES (critical - this is voice output):
- Keep responses to 1-3 sentences MAX. This is spoken aloud, not text.
- Never use markdown, bullet points, asterisks, or formatting of any kind
- Never start a response with "I" - vary your sentence openings
- Use contractions naturally ("I'm", "you've", "that's")
- If asked something complex, summarize concisely rather than explaining fully
- For opinions, give one clear measured view rather than listing multiple perspectives
- Never say "Certainly!", "Absolutely!", "Of course!" - too eager
- Preferred acknowledgments: "Of course, sir.", "Right away.", "Understood.", "Very well."

KNOWLEDGE:
- You have access to the user's computer, calendar, email, notes, and reminders
- You can control their PC, browser, and applications
- Current date/time: {datetime}
- Long-term memories about this user: {memories}

TONE EXAMPLES:
- Good: "Seventeen unread emails, sir. Three appear to require your attention."
- Bad: "I found 17 emails! Here's a breakdown of each one..."
- Good: "That's a rather optimistic timeline, if you don't mind my saying so."
- Bad: "Great question! Let me help you think through this!"
"""

_history = []
_long_memory = {}


def _load_memory():
    global _long_memory
    if os.path.exists(MEMORY_FILE):
        try:
            with open(MEMORY_FILE, "r") as f:
                _long_memory = json.load(f)
        except Exception:
            _long_memory = {}


def _save_memory():
    with open(MEMORY_FILE, "w") as f:
        json.dump(_long_memory, f, indent=2)


def remember(key: str, value: str):
    """Store something in long-term memory."""
    _load_memory()
    _long_memory[key] = {"value": value, "stored": datetime.now().isoformat()}
    _save_memory()


def recall(key: str) -> str | None:
    """Retrieve something from long-term memory."""
    _load_memory()
    entry = _long_memory.get(key)
    return entry["value"] if entry else None


def forget(key: str) -> bool:
    """Remove something from long-term memory."""
    _load_memory()
    if key in _long_memory:
        del _long_memory[key]
        _save_memory()
        return True
    return False


def get_all_memories() -> dict:
    _load_memory()
    return _long_memory.copy()


def _build_system():
    _load_memory()
    memory_str = "None stored yet."
    if _long_memory:
        items = [f"{k}: {v['value']}" for k, v in list(_long_memory.items())[-10:]]
        memory_str = "; ".join(items)
    return SYSTEM_PROMPT.format(
        datetime=datetime.now().strftime("%A, %B %d %Y, %I:%M %p"),
        memories=memory_str
    )


def chat(user_message: str) -> str:
    global _history
    _history.append({"role": "user", "content": user_message})
    if len(_history) > MAX_HISTORY:
        _history = _history[-MAX_HISTORY:]

    # Check if user is trying to store a memory via natural language
    mem_result = _try_extract_memory(user_message)
    if mem_result:
        return mem_result

    try:
        payload = {
            "model": MODEL,
            "messages": [
                {"role": "system", "content": _build_system()},
                *_history
            ],
            "stream": False,
            "options": {
                "temperature": 0.75,
                "num_predict": 100,
                "top_p": 0.9,
                "repeat_penalty": 1.1,
            }
        }
        r = requests.post(OLLAMA_URL, json=payload, timeout=15)
        if r.status_code == 200:
            reply = r.json()["message"]["content"].strip()
            # Strip any markdown that slips through
            reply = re.sub(r'\*+', '', reply)
            reply = re.sub(r'#+\s*', '', reply)
            reply = re.sub(r'\n+', ' ', reply).strip()
            # Enforce length - cut at 3 sentences
            sentences = re.split(r'(?<=[.!?])\s+', reply)
            if len(sentences) > 3:
                reply = ' '.join(sentences[:3])
            _history.append({"role": "assistant", "content": reply})
            return reply
    except Exception as e:
        print(f"[brain] Ollama error: {e}")
        _history.pop()

    return _fallback(user_message)


def _try_extract_memory(text: str) -> str | None:
    """Detects memory storage requests like 'remember that my car is a Tesla'."""
    t = text.lower()
    patterns = [
        r"remember (?:that )?(?:my )?(.+?) is (.+)",
        r"remember (?:that )?i (?:am|am a|like|hate|prefer|have|own) (.+)",
        r"don't forget (?:that )?(.+)",
        r"note (?:that )?(.+)",
        r"my (.+?) is (.+)",
    ]
    for pat in patterns:
        m = re.match(pat, t)
        if m:
            if len(m.groups()) == 2:
                key, val = m.group(1).strip(), m.group(2).strip()
            else:
                key = "note"
                val = m.group(1).strip()
            remember(key, val)
            return f"Noted, sir. I'll remember that {key} is {val}."
    return None


def reset_conversation():
    global _history
    _history = []
    return "Conversation history cleared, sir."


def _fallback(text: str) -> str:
    t = text.lower()
    if any(x in t for x in ["how are you", "you okay"]): 
        return "All systems nominal, sir."
    if any(x in t for x in ["thank you", "thanks"]): 
        return "Of course, sir."
    if any(x in t for x in ["who are you", "what are you"]): 
        return "JARVIS, sir. Just A Rather Very Intelligent System. At your service."
    if any(x in t for x in ["joke", "funny"]): 
        return "Why do programmers prefer dark mode? Because light attracts bugs, sir."
    return "I'm afraid I need Ollama running to answer that properly, sir."
