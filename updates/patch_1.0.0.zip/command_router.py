"""
JARVIS Command Router v4
- Keyword matching runs FIRST before Ollama for known commands
- Ollama only handles truly unknown/conversational input
- Fixes email/calendar being misrouted to CONVERSE
"""

import re
import subprocess
import webbrowser
import requests

from clock import get_current_time_str, get_current_date_str, get_greeting_line
from input_control import scroll, hotkey, type_text, screenshot
from app_launcher import open_app
from browser_control import (new_tab, close_tab, navigate, search_google,
    click_first_result, search_youtube, click_top_youtube_result,
    go_back, go_forward, next_tab, prev_tab, refresh, zoom_in, zoom_out,
    search_in_page)
from medal_control import trigger_clip, is_clip_command
from sleep_mode import check_sleep_command, check_wake_command, set_sleeping, is_sleeping

try:
    from orb_overlay import signals as orb_signals
    _gui = True
except ImportError:
    _gui = False

def _dock(d):
    if _gui: orb_signals.dock_to_corner.emit(d)
def _desktop(a):
    if _gui: orb_signals.desktop_mode.emit(a)

try:
    from discord_compose import compose_and_send_discord, check_discord
    _discord = True
except ImportError:
    _discord = False

try:
    from email_client import check_recent_emails
    from email_compose import compose_and_send_email
    _email = True
except ImportError:
    _email = False

try:
    from calendar_compose import compose_and_create_event, check_calendar
    _calendar = True
except ImportError:
    _calendar = False

try:
    from brain import chat
    _brain = True
except ImportError:
    _brain = False

try:
    from games import is_playing, try_start_game, handle_game_input, stop_game
    _games = True
except ImportError:
    _games = False


# ---------------------------------------------------------------------------
# Keyword intent — runs FIRST, always, before Ollama
# These are explicit matches that must never fall through to AI
# ---------------------------------------------------------------------------
def _keyword_intent(t: str) -> str | None:
    """Returns an intent string if the text clearly matches a known command,
    or None if it should go to Ollama for natural language understanding."""

    # Sleep / wake
    if check_sleep_command(t): return "SLEEP"
    if check_wake_command(t): return "WAKE"

    # Desktop / HUD
    if any(x in t for x in ["open desktop", "show desktop mode", "hide jarvis",
                              "open my desktop", "minimize jarvis"]): return "OPEN_DESKTOP"
    if any(x in t for x in ["open hud", "show hud", "bring back jarvis",
                              "open fullscreen", "full screen jarvis"]): return "OPEN_HUD"

    # Time / date
    if any(x in t for x in ["what time", "current time", "time is it",
                              "tell me the time", "what's the time"]): return "TIME"
    if any(x in t for x in ["what date", "today's date", "what day",
                              "what's the date", "what is the date"]): return "DATE"
    if any(x in t for x in ["good morning", "good evening", "good afternoon"]): return "GREETING"

    # Email — explicit triggers that must never go to AI
    if any(x in t for x in [
        "check my email", "check email", "read my email", "read email",
        "any new emails", "new emails", "my emails", "do i have email",
        "check my emails", "any emails"
    ]): return "CHECK_EMAIL"

    if any(x in t for x in [
        "send an email", "send email", "compose email", "write an email",
        "write email", "email someone", "email to"
    ]): return "SEND_EMAIL"

    # Calendar — explicit triggers
    if any(x in t for x in [
        "check my calendar", "check calendar", "my calendar",
        "upcoming events", "what do i have", "what's on my calendar",
        "whats on my calendar", "any events"
    ]): return "CHECK_CALENDAR"

    if any(x in t for x in [
        "add an event", "add event", "new event", "create event",
        "schedule something", "add to my calendar", "add to calendar",
        "remind me", "set a reminder"
    ]): return "ADD_CALENDAR"

    # Discord
    if any(x in t for x in ["send discord", "discord message",
                              "message on discord", "send a discord"]): return "SEND_DISCORD"
    if any(x in t for x in ["check discord", "discord messages",
                              "read discord"]): return "CHECK_DISCORD"

    # Browser
    if any(x in t for x in ["new tab", "open a new tab", "open tab"]): return "NEW_TAB"
    if any(x in t for x in ["close tab", "shut tab"]): return "CLOSE_TAB"
    if any(x in t for x in ["next tab", "switch tab"]): return "NEXT_TAB"
    if any(x in t for x in ["previous tab", "prev tab"]): return "PREV_TAB"
    if any(x in t for x in ["go back", "back"]): return "GO_BACK"
    if any(x in t for x in ["go forward", "forward"]): return "GO_FORWARD"
    if any(x in t for x in ["refresh", "reload page"]): return "REFRESH"
    if any(x in t for x in ["zoom in"]): return "ZOOM_IN"
    if any(x in t for x in ["zoom out"]): return "ZOOM_OUT"
    if any(x in t for x in ["click first result", "open first result",
                              "click top result"]): return "CLICK_FIRST"
    if any(x in t for x in ["click top youtube", "open first youtube",
                              "top youtube result"]): return "CLICK_TOP_YOUTUBE"

    # YouTube search
    for pat in [r"search (?:for |in )?youtube (?:for )?(.+)",
                r"(?:play|find) (.+?) on youtube",
                r"youtube (?:search )?(?:for )?(.+)"]:
        m = re.search(pat, t)
        if m: return f"SEARCH_YOUTUBE:{m.group(1).strip()}"

    # Google search
    for pat in [r"search google (?:for )?(.+)",
                r"google (.+)", r"look up (.+)",
                r"search for (.+) online", r"search (?:for )?(.+)"]:
        m = re.search(pat, t)
        if m: return f"SEARCH_GOOGLE:{m.group(1).strip()}"

    # Navigate
    m = re.search(r"(?:go to|navigate to|take me to|open) ([\w\.\-]+\.(?:com|org|net|io|co|tv|gg|app|dev|gov|edu)\S*)", t)
    if m: return f"NAVIGATE:{m.group(1).strip()}"

    # Type dictation
    m = re.match(r"^(?:type|write|type out) (.+)$", t)
    if m: return f"TYPE:{m.group(1)}"

    # Input controls
    if any(x in t for x in ["scroll down", "go down", "move down"]): return "SCROLL_DOWN"
    if any(x in t for x in ["scroll up", "go up", "move up"]): return "SCROLL_UP"
    if any(x in t for x in ["switch window", "alt tab", "change window"]): return "SWITCH_WINDOW"
    if any(x in t for x in ["show desktop", "minimize all",
                              "minimize everything"]): return "SHOW_DESKTOP"
    if any(x in t for x in ["close window", "close app", "close this"]): return "CLOSE_WINDOW"
    if any(x in t for x in ["copy that", "copy this", "copy it"]): return "COPY"
    if any(x in t for x in ["paste that", "paste this", "paste it"]): return "PASTE"
    if any(x in t for x in ["screenshot", "take a screenshot",
                              "screenie", "capture screen"]): return "SCREENSHOT"

    # Medal clip
    if is_clip_command(t): return "CLIP"

    # PC control
    if any(x in t for x in ["lock computer", "lock my computer",
                              "lock screen"]): return "LOCK"
    if any(x in t for x in ["shut down", "shutdown",
                              "turn off computer"]): return "SHUTDOWN"
    if any(x in t for x in ["restart", "reboot"]): return "RESTART"
    if any(x in t for x in ["sleep computer", "put computer to sleep"]): return "SLEEP_PC"

    # Open app — must be last to avoid grabbing non-app phrases
    m = re.match(r"(?:open|launch|start|run) (.+)", t)
    if m:
        name = m.group(1).strip()
        # Don't match things like "open desktop", "open hud" (handled above)
        if name not in ["desktop", "hud", "my desktop", "my hud"]:
            return f"OPEN_APP:{name}"

    return None  # fall through to Ollama


# ---------------------------------------------------------------------------
# Ollama — only for truly unknown / conversational input
# ---------------------------------------------------------------------------
def _ollama_chat(text: str) -> str:
    if not _brain:
        return f"I'm not sure how to help with that, sir."
    try:
        return chat(text)
    except Exception as e:
        return f"I'm having trouble thinking right now, sir. ({e})"


# ---------------------------------------------------------------------------
# Main dispatcher
# ---------------------------------------------------------------------------
def handle_command(text: str) -> str:
    if not text:
        return "I didn't catch that, sir."

    # Games take priority if one is active
    if _games:
        if is_playing():
            if any(x in text.lower() for x in ["stop game", "end game",
                                                 "quit game", "stop playing"]):
                return stop_game()
            return handle_game_input(text)
        game_resp = try_start_game(text)
        if game_resp:
            return game_resp

    if is_sleeping():
        if check_wake_command(text.lower()):
            set_sleeping(False)
            return "Good to be back, sir."
        return ""

    # Run keyword matching first — never let known commands go to AI
    intent = _keyword_intent(text.lower().strip())

    if intent is None:
        # Nothing matched — let the AI handle it conversationally
        print("[router] Intent: CONVERSE")
        return _ollama_chat(text)

    print(f"[router] Intent: {intent}")

    if intent == "SLEEP":
        set_sleeping(True)
        return "Goodnight, sir. I'll be here when you need me."
    if intent == "WAKE":
        set_sleeping(False)
        return "Good morning, sir."
    if intent == "TIME": return f"It's {get_current_time_str()}."
    if intent == "DATE": return f"Today is {get_current_date_str()}."
    if intent == "GREETING": return get_greeting_line()

    if intent == "OPEN_DESKTOP":
        _dock(True); _desktop(True)
        return "Opening your desktop, sir."
    if intent == "OPEN_HUD":
        _dock(False); _desktop(False)
        return "HUD restored, sir."

    # Browser
    if intent == "NEW_TAB": new_tab(); _dock(True); return "New tab opened."
    if intent == "CLOSE_TAB": close_tab(); return "Tab closed."
    if intent == "NEXT_TAB": next_tab(); return "Next tab."
    if intent == "PREV_TAB": prev_tab(); return "Previous tab."
    if intent == "GO_BACK": go_back(); return "Going back."
    if intent == "GO_FORWARD": go_forward(); return "Going forward."
    if intent == "REFRESH": refresh(); return "Refreshed."
    if intent == "ZOOM_IN": zoom_in(); return "Zoomed in."
    if intent == "ZOOM_OUT": zoom_out(); return "Zoomed out."
    if intent == "CLICK_FIRST": click_first_result(); return "Clicking the first result."
    if intent == "CLICK_TOP_YOUTUBE": click_top_youtube_result(); return "Opening top result."
    if intent.startswith("SEARCH_GOOGLE:"):
        q = intent[14:]; search_google(q); _dock(True); return f"Searching Google for {q}."
    if intent.startswith("SEARCH_YOUTUBE:"):
        q = intent[15:]; search_youtube(q); _dock(True); return f"Searching YouTube for {q}."
    if intent.startswith("NAVIGATE:"):
        url = intent[9:]; navigate(url); _dock(True); return f"Navigating to {url}."

    # Input
    if intent == "SCROLL_DOWN": scroll(-400); return "Scrolling down."
    if intent == "SCROLL_UP": scroll(400); return "Scrolling up."
    if intent == "SWITCH_WINDOW": hotkey("alt", "tab"); return "Switching windows."
    if intent == "SHOW_DESKTOP": hotkey("win", "d"); return "Showing desktop."
    if intent == "CLOSE_WINDOW": hotkey("alt", "f4"); return "Closing window."
    if intent == "COPY": hotkey("ctrl", "c"); return "Copied."
    if intent == "PASTE": hotkey("ctrl", "v"); return "Pasted."
    if intent == "SCREENSHOT":
        screenshot(save_path="jarvis_screenshot.png"); return "Screenshot saved."
    if intent == "CLIP": return trigger_clip()
    if intent.startswith("TYPE:"): type_text(intent[5:]); return "Done."

    # PC control
    if intent == "LOCK": hotkey("win", "l"); return "Locking your computer, sir."
    if intent == "SHUTDOWN":
        subprocess.Popen("shutdown /s /t 10", shell=True)
        return "Shutting down in 10 seconds, sir."
    if intent == "RESTART":
        subprocess.Popen("shutdown /r /t 10", shell=True)
        return "Restarting in 10 seconds, sir."
    if intent == "SLEEP_PC":
        subprocess.Popen("rundll32.exe powrprof.dll,SetSuspendState 0,1,0", shell=True)
        return "Putting your computer to sleep, sir."

    # Apps
    if intent.startswith("OPEN_APP:"):
        name = intent[9:]
        result = open_app(name); _dock(True); return result

    # Email
    if intent == "CHECK_EMAIL":
        if not _email: return "Email isn't configured yet, sir."
        try:
            emails = check_recent_emails(count=3)
        except Exception as e:
            return f"I couldn't check your email. {e}"
        if not emails: return "No new emails, sir."
        first = emails[0]
        return (f"You have {len(emails)} new emails. "
                f"Most recent from {first['from']}, "
                f"subject: {first['subject']}.")
    if intent == "SEND_EMAIL":
        if not _email: return "Email isn't configured yet, sir."
        return compose_and_send_email()

    # Calendar
    if intent == "CHECK_CALENDAR":
        if not _calendar: return "Calendar isn't configured yet, sir."
        return check_calendar()
    if intent == "ADD_CALENDAR":
        if not _calendar: return "Calendar isn't configured yet, sir."
        return compose_and_create_event()

    # Discord
    if intent == "SEND_DISCORD":
        if not _discord: return "Discord isn't set up yet, sir."
        return compose_and_send_discord()
    if intent == "CHECK_DISCORD":
        if not _discord: return "Discord isn't set up yet, sir."
        return check_discord("general")

    return _ollama_chat(text)


if __name__ == "__main__":
    print("Command router test (type commands, Ctrl+C to quit):")
    while True:
        try:
            user_text = input("> ")
            print(handle_command(user_text))
        except KeyboardInterrupt:
            break


# ---------------------------------------------------------------------------
# Patch: wire in timers, notes, upgraded brain, Discord
# ---------------------------------------------------------------------------
from reminders import parse_timer_command, set_fire_callback
from notes import parse_note_command
from brain import chat, remember, recall, get_all_memories, reset_conversation

try:
    from discord_compose import compose_and_send_discord, check_discord
    _discord = True
except ImportError:
    _discord = False

_original_handle = handle_command


def handle_command(text: str) -> str:
    if not text:
        return "I didn't catch that, sir."

    # Games
    if _games:
        if is_playing():
            if any(x in text.lower() for x in ["stop game","end game","quit game"]):
                return stop_game()
            return handle_game_input(text)
        game_resp = try_start_game(text)
        if game_resp:
            return game_resp

    if is_sleeping():
        if check_wake_command(text.lower()):
            set_sleeping(False)
            return "Good to be back, sir."
        return ""

    t = text.lower().strip()

    # Memory commands
    if any(x in t for x in ["what do you remember", "your memories",
                              "what do you know about me"]):
        mems = get_all_memories()
        if not mems:
            return "I don't have anything stored in long-term memory yet, sir."
        items = list(mems.items())[:4]
        summary = "; ".join(f"{k}: {v['value']}" for k, v in items)
        return f"Here's what I remember, sir: {summary}."

    if any(x in t for x in ["forget everything", "clear your memory",
                              "reset conversation"]):
        reset_conversation()
        return "Conversation cleared, sir."

    # Notes
    note_resp = parse_note_command(text)
    if note_resp:
        return note_resp

    # Timers / reminders / alarms
    timer_resp = parse_timer_command(text)
    if timer_resp:
        return timer_resp

    # Discord
    if any(x in t for x in ["send discord", "discord message",
                              "message on discord"]):
        if not _discord:
            return "Discord isn't set up yet, sir."
        return compose_and_send_discord()
    if any(x in t for x in ["check discord", "discord messages"]):
        if not _discord:
            return "Discord isn't set up yet, sir."
        return check_discord("general")

    # Route through original handler
    result = _original_handle(text)

    # If nothing matched, use upgraded brain
    if "I'm not sure how to help" in result or result == "":
        return chat(text)

    return result
