"""
JARVIS News Module (RSS feeds - completely free, no API key)
"""
import requests
import xml.etree.ElementTree as ET

RSS_FEEDS = {
    "general": "https://feeds.bbci.co.uk/news/rss.xml",
    "tech": "https://feeds.feedburner.com/TechCrunch",
    "us": "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml",
    "world": "https://feeds.bbci.co.uk/news/world/rss.xml",
}

def get_headlines(category: str = "general", count: int = 3) -> str:
    feed_url = RSS_FEEDS.get(category.lower(), RSS_FEEDS["general"])
    try:
        r = requests.get(feed_url, timeout=5,
                        headers={"User-Agent": "JARVIS/1.0"})
        root = ET.fromstring(r.content)
        items = root.findall(".//item")[:count]
        if not items:
            return "I couldn't find any headlines right now."
        headlines = [item.find("title").text.strip() for item in items
                    if item.find("title") is not None]
        result = f"Here are the top {len(headlines)} headlines. "
        for i, h in enumerate(headlines, 1):
            result += f"{i}: {h}. "
        return result
    except Exception as e:
        return f"I couldn't fetch the news right now. {e}"

if __name__ == "__main__":
    print(get_headlines())
