"""
JARVIS Games Module
--------------------
Voice-playable games JARVIS can run. All games are turn-based and
work purely through speech — JARVIS speaks the state, you respond,
JARVIS reacts.

Available games:
    - 20 Questions (JARVIS thinks of something, you guess)
    - Trivia (JARVIS asks questions, keeps score)
    - Word Association
    - Would You Rather
    - Number guessing (you think of a number, JARVIS guesses)
    - Riddles
"""

import random
from brain import chat

# ---------------------------------------------------------------------------
# Game state
# ---------------------------------------------------------------------------
_active_game = None
_game_state = {}


def is_playing() -> bool:
    return _active_game is not None


def get_active_game() -> str | None:
    return _active_game


def stop_game() -> str:
    global _active_game, _game_state
    game = _active_game
    _active_game = None
    _game_state = {}
    if game:
        return f"Ending {game}, sir."
    return "No game is currently running, sir."


# ---------------------------------------------------------------------------
# 20 Questions
# ---------------------------------------------------------------------------
TWENTY_Q_THINGS = [
    ("elephant", "animal"), ("guitar", "object"), ("Mount Everest", "place"),
    ("pizza", "food"), ("the sun", "thing"), ("Shakespeare", "person"),
    ("submarine", "vehicle"), ("diamond", "mineral"), ("chess", "game"),
    ("lightning", "natural phenomenon"), ("violin", "instrument"),
    ("the Eiffel Tower", "landmark"), ("oxygen", "element"),
    ("basketball", "sport"), ("volcano", "geological feature"),
]

def start_20_questions() -> str:
    global _active_game, _game_state
    _active_game = "20 questions"
    thing, category = random.choice(TWENTY_Q_THINGS)
    _game_state = {"thing": thing, "category": category, "questions": 0, "max": 20}
    return (
        f"I'm thinking of a {category}. You have 20 yes-or-no questions to figure it out. "
        f"Ask away, sir."
    )

def handle_20_questions(user_input: str) -> str:
    global _active_game, _game_state
    state = _game_state
    thing = state["thing"]
    state["questions"] += 1
    remaining = state["max"] - state["questions"]

    # Check for a direct guess
    if any(x in user_input.lower() for x in ["is it", "could it be", "i think it's", "my guess is"]):
        if thing.lower() in user_input.lower():
            _active_game = None
            _game_state = {}
            return f"Correct, sir! It was {thing}. Well played — {state['questions']} questions."
        else:
            return f"No, that's not it. {remaining} questions remaining."

    if remaining <= 0:
        _active_game = None
        _game_state = {}
        return f"Out of questions, sir. I was thinking of {thing}. Better luck next time."

    # Use JARVIS brain to answer yes/no
    prompt = (
        f"We're playing 20 questions. The answer is '{thing}' (a {state['category']}). "
        f"The user asked: '{user_input}'. "
        f"Answer ONLY yes, no, or sometimes. One word only, nothing else."
    )
    answer = chat(prompt).lower().strip().rstrip(".")
    # Clean to just the key word
    if "yes" in answer: answer = "Yes"
    elif "no" in answer: answer = "No"
    elif "sometimes" in answer or "sort of" in answer: answer = "Sometimes"
    else: answer = "I'm not sure"

    return f"{answer}. {remaining} questions left."


# ---------------------------------------------------------------------------
# Trivia
# ---------------------------------------------------------------------------
TRIVIA = [
    ("What is the capital of France?", "Paris"),
    ("How many sides does a hexagon have?", "Six"),
    ("What planet is known as the Red Planet?", "Mars"),
    ("Who wrote Romeo and Juliet?", "Shakespeare"),
    ("What is the chemical symbol for gold?", "Au"),
    ("How many bones are in the adult human body?", "206"),
    ("What is the fastest land animal?", "Cheetah"),
    ("In what year did World War Two end?", "1945"),
    ("What is the largest ocean on Earth?", "Pacific"),
    ("Who painted the Mona Lisa?", "Leonardo da Vinci"),
    ("What gas do plants absorb from the atmosphere?", "Carbon dioxide"),
    ("How many players are on a basketball team on the court?", "Five"),
    ("What is the hardest natural substance on Earth?", "Diamond"),
    ("What country invented pizza?", "Italy"),
    ("How many hours are in a week?", "168"),
]

def start_trivia() -> str:
    global _active_game, _game_state
    _active_game = "trivia"
    questions = random.sample(TRIVIA, min(5, len(TRIVIA)))
    _game_state = {"questions": questions, "current": 0, "score": 0}
    first_q = questions[0][0]
    return f"Trivia time, sir. Five questions. Here's the first: {first_q}"

def handle_trivia(user_input: str) -> str:
    global _active_game, _game_state
    state = _game_state
    idx = state["current"]
    question, correct = state["questions"][idx]

    # Check answer (fuzzy)
    correct_words = set(correct.lower().split())
    user_words = set(user_input.lower().split())
    if correct_words & user_words or correct.lower() in user_input.lower():
        state["score"] += 1
        result = "Correct!"
    else:
        result = f"Not quite — the answer was {correct}."

    state["current"] += 1
    if state["current"] >= len(state["questions"]):
        score = state["score"]
        total = len(state["questions"])
        _active_game = None
        _game_state = {}
        verdict = "Excellent" if score == total else "Not bad" if score >= total//2 else "Room to improve"
        return f"{result} Final score: {score} out of {total}. {verdict}, sir."

    next_q = state["questions"][state["current"]][0]
    return f"{result} Score: {state['score']}. Next: {next_q}"


# ---------------------------------------------------------------------------
# Number Guessing (JARVIS guesses YOUR number)
# ---------------------------------------------------------------------------
def start_number_guess() -> str:
    global _active_game, _game_state
    _active_game = "number guess"
    _game_state = {"low": 1, "high": 100, "attempts": 0}
    mid = 50
    _game_state["last_guess"] = mid
    return (
        "Think of a number between 1 and 100, sir. Don't tell me — I'll figure it out. "
        "Ready? Is it 50?"
    )

def handle_number_guess(user_input: str) -> str:
    global _active_game, _game_state
    state = _game_state
    state["attempts"] += 1
    t = user_input.lower()
    last = state["last_guess"]

    if any(x in t for x in ["correct", "yes", "that's it", "right", "yeah"]):
        _active_game = None
        return f"Got it in {state['attempts']} attempts. {last} it is. Binary search, sir — works every time."

    if any(x in t for x in ["higher", "more", "bigger", "up"]):
        state["low"] = last + 1
    elif any(x in t for x in ["lower", "less", "smaller", "down"]):
        state["high"] = last - 1
    else:
        return "Please say higher, lower, or correct, sir."

    if state["low"] > state["high"]:
        _active_game = None
        return "Something doesn't add up, sir. Are you sure you're being consistent?"

    mid = (state["low"] + state["high"]) // 2
    state["last_guess"] = mid
    return f"Is it {mid}?"


# ---------------------------------------------------------------------------
# Riddles
# ---------------------------------------------------------------------------
RIDDLES = [
    ("The more you take, the more you leave behind. What am I?", "Footsteps"),
    ("I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I?", "An echo"),
    ("What has hands but can't clap?", "A clock"),
    ("The more you have of it, the less you see. What is it?", "Darkness"),
    ("What can travel around the world while staying in a corner?", "A stamp"),
    ("I have cities, but no houses live there. I have mountains, but no trees grow there. What am I?", "A map"),
    ("What gets wetter as it dries?", "A towel"),
]

def start_riddles() -> str:
    global _active_game, _game_state
    _active_game = "riddles"
    riddles = random.sample(RIDDLES, len(RIDDLES))
    _game_state = {"riddles": riddles, "current": 0, "score": 0, "revealed": False}
    return f"Riddles it is, sir. Here's the first: {riddles[0][0]}"

def handle_riddles(user_input: str) -> str:
    global _active_game, _game_state
    state = _game_state
    idx = state["current"]
    riddle, answer = state["riddles"][idx]
    t = user_input.lower()

    if any(x in t for x in ["give up", "i don't know", "tell me", "what is it"]):
        state["current"] += 1
        state["revealed"] = False
        if state["current"] >= len(state["riddles"]):
            _active_game = None
            return f"The answer was {answer}. Score: {state['score']} out of {idx+1}. Well attempted, sir."
        next_r = state["riddles"][state["current"]][0]
        return f"The answer was {answer}. Next riddle: {next_r}"

    if answer.lower() in t or any(w in t for w in answer.lower().split()):
        state["score"] += 1
        state["current"] += 1
        if state["current"] >= len(state["riddles"]):
            _active_game = None
            return f"Correct! Score: {state['score']} out of {state['current']}. Well done, sir."
        next_r = state["riddles"][state["current"]][0]
        return f"Correct! Score: {state['score']}. Next: {next_r}"

    return "Not quite. Try again, or say 'give up' for the answer, sir."


# ---------------------------------------------------------------------------
# Main dispatcher
# ---------------------------------------------------------------------------
GAME_STARTERS = {
    "20 questions": start_20_questions,
    "twenty questions": start_20_questions,
    "trivia": start_trivia,
    "quiz": start_trivia,
    "number guessing": start_number_guess,
    "guess my number": start_number_guess,
    "riddles": start_riddles,
    "riddle": start_riddles,
}

def try_start_game(text: str) -> str | None:
    """Returns game intro if text matches a game starter, else None."""
    t = text.lower()
    for phrase, starter in GAME_STARTERS.items():
        if phrase in t:
            return starter()
    return None

def handle_game_input(text: str) -> str:
    """Routes input to the active game's handler."""
    if _active_game == "20 questions":
        return handle_20_questions(text)
    if _active_game == "trivia":
        return handle_trivia(text)
    if _active_game == "number guess":
        return handle_number_guess(text)
    if _active_game == "riddles":
        return handle_riddles(text)
    return "No game is active, sir."
