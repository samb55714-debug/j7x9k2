"""
JARVIS Wake Word Module - openWakeWord
"""

import numpy as np
import sounddevice as sd
from openwakeword.model import Model
import openwakeword

SAMPLE_RATE = 16000
FRAME_SIZE = 1280
DETECTION_THRESHOLD = 0.5
COOLDOWN_FRAMES = 25


def _ensure_models():
    try:
        openwakeword.utils.download_models(["hey_jarvis"])
    except Exception as e:
        print(f"[wake_word] Model check: {e}")


def listen_for_wake_word(on_detected, wakeword="hey_jarvis",
                         threshold=DETECTION_THRESHOLD):
    _ensure_models()
    model = Model(wakeword_models=[wakeword], inference_framework="onnx")
    cooldown = 0
    print(f'[wake_word] Listening for "Hey Jarvis"...')

    def audio_callback(indata, frames, time_info, status):
        nonlocal cooldown
        # Suppress the overflow warning — it's cosmetic with latency=high
        audio_chunk = indata[:, 0].astype(np.int16)
        predictions = model.predict(audio_chunk)
        score = predictions.get(wakeword, 0.0)
        if cooldown > 0:
            cooldown -= 1
            return
        if score > threshold:
            print(f"[wake_word] Detected! (score: {score:.2f})")
            cooldown = COOLDOWN_FRAMES
            on_detected()

    with sd.InputStream(
        samplerate=SAMPLE_RATE,
        blocksize=FRAME_SIZE,
        channels=1,
        dtype="int16",
        latency="high",
        extra_settings=sd.AsioSettings(channel_selectors=[0]) if False else None,
        callback=audio_callback,
    ):
        while True:
            sd.sleep(100)


if __name__ == "__main__":
    def _on_wake():
        print(">>> Wake word heard!")
    listen_for_wake_word(_on_wake)
