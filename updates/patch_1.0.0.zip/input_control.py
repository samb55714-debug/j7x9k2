"""
JARVIS Input Control Module
------------------------------
Gives JARVIS full control of your mouse, keyboard, and scroll wheel.

SAFETY NOTE: pyautogui has a built-in failsafe - slam your mouse into
any corner of the screen at any time to instantly abort whatever it's
doing. Don't disable this (it's off by default here... actually it's
ON by default, and this file keeps it on intentionally).

Usage:
    python input_control.py
    -> runs a small demo: moves mouse, types text, scrolls

To use it from other modules:
    from input_control import move_mouse, click, type_text, scroll, press_key, hotkey

Install:
    pip install pyautogui
"""

import time
import pyautogui

# Keep the failsafe ON - moving the mouse to a screen corner aborts
# whatever pyautogui is doing. This is your emergency stop.
pyautogui.FAILSAFE = True

# Small delay between actions so things don't fire faster than apps can
# react to them. Lower = faster but less reliable; raise if things get flaky.
pyautogui.PAUSE = 0.05


def get_screen_size():
    return pyautogui.size()  # (width, height)


def get_mouse_position():
    return pyautogui.position()  # (x, y)


def move_mouse(x: int, y: int, duration: float = 0.2):
    """Moves the mouse to an absolute screen position."""
    pyautogui.moveTo(x, y, duration=duration)


def move_mouse_relative(dx: int, dy: int, duration: float = 0.2):
    """Moves the mouse relative to its current position."""
    pyautogui.moveRel(dx, dy, duration=duration)


def click(x: int = None, y: int = None, button: str = "left", clicks: int = 1):
    """Clicks at (x, y) if given, otherwise at the current mouse position."""
    pyautogui.click(x=x, y=y, button=button, clicks=clicks)


def double_click(x: int = None, y: int = None):
    pyautogui.doubleClick(x=x, y=y)


def right_click(x: int = None, y: int = None):
    pyautogui.click(x=x, y=y, button="right")


def drag_to(x: int, y: int, duration: float = 0.4, button: str = "left"):
    pyautogui.dragTo(x, y, duration=duration, button=button)


def scroll(amount: int):
    """
    Positive = scroll up, negative = scroll down.
    Roughly ~100 units is a small nudge, ~500+ is a big scroll.
    """
    pyautogui.scroll(amount)


def type_text(text: str, interval: float = 0.02):
    """Types text as if typed on the keyboard, character by character."""
    pyautogui.write(text, interval=interval)


def press_key(key: str):
    """Presses a single key, e.g. 'enter', 'esc', 'tab', 'up', 'f5'."""
    pyautogui.press(key)


def hotkey(*keys):
    """
    Presses a key combination, e.g. hotkey('ctrl', 'c') for copy,
    hotkey('alt', 'tab') to switch windows, hotkey('win', 'd') to
    show desktop.
    """
    pyautogui.hotkey(*keys)


def screenshot(save_path: str = None):
    """Takes a screenshot. Returns a PIL Image; saves to disk if path given."""
    img = pyautogui.screenshot()
    if save_path:
        img.save(save_path)
    return img


if __name__ == "__main__":
    print("Running a short input control demo in 3 seconds...")
    print("(Move your mouse to a screen corner at any time to abort)")
    time.sleep(3)

    w, h = get_screen_size()
    print(f"Screen size: {w}x{h}")

    print("Moving mouse to center of screen...")
    move_mouse(w // 2, h // 2)

    print("Scrolling down a bit...")
    scroll(-300)
    time.sleep(0.5)
    print("Scrolling back up...")
    scroll(300)

    print("Demo complete.")
