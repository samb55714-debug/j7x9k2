"""
JARVIS System Info Module
"""
import psutil
import socket

def get_system_summary() -> str:
    parts = []

    # CPU
    cpu = psutil.cpu_percent(interval=0.5)
    parts.append(f"CPU at {cpu}%")

    # RAM
    ram = psutil.virtual_memory()
    used_gb = ram.used / (1024**3)
    total_gb = ram.total / (1024**3)
    parts.append(f"RAM {used_gb:.1f} of {total_gb:.1f} GB used ({ram.percent}%)")

    # Battery
    battery = psutil.sensors_battery()
    if battery:
        status = "charging" if battery.power_plugged else "on battery"
        parts.append(f"battery at {round(battery.percent)}% and {status}")

    # Disk
    disk = psutil.disk_usage("/")
    free_gb = disk.free / (1024**3)
    parts.append(f"{free_gb:.0f} GB disk space free")

    # Network
    try:
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        parts.append(f"connected on {ip}")
    except Exception:
        parts.append("network status unknown")

    return "System status: " + ", ".join(parts) + "."

def get_cpu() -> str:
    cpu = psutil.cpu_percent(interval=0.5)
    freq = psutil.cpu_freq()
    cores = psutil.cpu_count()
    return f"CPU is at {cpu}% usage across {cores} cores at {freq.current:.0f} MHz."

def get_ram() -> str:
    ram = psutil.virtual_memory()
    used = ram.used / (1024**3)
    total = ram.total / (1024**3)
    return f"Using {used:.1f} of {total:.1f} gigabytes of RAM, that's {ram.percent}%."

def get_battery() -> str:
    b = psutil.sensors_battery()
    if not b:
        return "No battery detected — you're on a desktop, sir."
    status = "plugged in and charging" if b.power_plugged else "running on battery"
    mins = int(b.secsleft / 60) if b.secsleft > 0 and not b.power_plugged else None
    result = f"Battery is at {round(b.percent)}%, {status}."
    if mins:
        result += f" Approximately {mins} minutes remaining."
    return result

if __name__ == "__main__":
    print(get_system_summary())
    print(get_battery())
