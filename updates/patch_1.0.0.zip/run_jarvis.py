"""
JARVIS 24/7 Runner
-------------------
Keeps JARVIS running forever. If it crashes for any reason,
waits 5 seconds and restarts it automatically.
Logs everything to jarvis.log so you can see what happened.
"""

import subprocess
import time
import sys
import os
from datetime import datetime

LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "jarvis.log")
SCRIPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "main.py")
PYTHON = sys.executable  # uses whichever python is active (jarvis-env)
RESTART_DELAY = 5        # seconds to wait before restarting after a crash
MAX_CRASHES = 10         # stop trying after this many crashes in a row
CRASH_RESET_AFTER = 300  # reset crash counter if JARVIS ran for this many seconds


def log(msg: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def run():
    crash_count = 0

    log("=" * 60)
    log("JARVIS 24/7 runner started.")
    log(f"Python: {PYTHON}")
    log(f"Script: {SCRIPT}")
    log("=" * 60)

    while True:
        if crash_count >= MAX_CRASHES:
            log(f"JARVIS crashed {MAX_CRASHES} times in a row. Stopping.")
            log("Check jarvis.log for details, then restart run_jarvis.py manually.")
            break

        log(f"Starting JARVIS (attempt {crash_count + 1})...")
        start_time = time.time()

        try:
            result = subprocess.run(
                [PYTHON, SCRIPT],
                cwd=os.path.dirname(SCRIPT),
            )
            exit_code = result.returncode
        except Exception as e:
            log(f"Failed to launch: {e}")
            exit_code = -1

        runtime = time.time() - start_time

        if runtime > CRASH_RESET_AFTER:
            # Ran long enough — reset crash counter
            crash_count = 0
            log(f"JARVIS ran for {runtime:.0f}s then exited (code {exit_code}). Restarting...")
        else:
            crash_count += 1
            log(f"JARVIS exited after {runtime:.0f}s (code {exit_code}). Crash #{crash_count}.")

        if exit_code == 0:
            # Clean exit (user closed it intentionally) — still restart
            log("Clean exit detected. Restarting in 3 seconds...")
            time.sleep(3)
        else:
            log(f"Restarting in {RESTART_DELAY} seconds...")
            time.sleep(RESTART_DELAY)


if __name__ == "__main__":
    run()
