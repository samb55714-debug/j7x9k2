"""
JARVIS STT v8 - optimized for command accuracy
Key changes:
- Records for a fixed window THEN transcribes (more reliable than silence detection)
- Aggressive gain to compensate for quiet mic
- Google STT with language hints for JARVIS commands
- Whisper fallback with corrections
"""

import re
import wave
import tempfile
import os
import numpy as np
import sounddevice as sd
import time

SAMPLE_RATE = 16000
GAIN = 1.5  # mic already loud - minimal boost
SPEECH_RMS = 0.03   # your mic RMS is ~0.086 so this catches speech easily
SILENCE_RMS = 0.02  # silence floor for your mic

# These are phrases Google will weight higher when transcribing
# Dramatically improves accuracy for known commands
GOOGLE_HINTS = [
    "open desktop", "open HUD", "open Chrome", "open Discord",
    "open Spotify", "open Roblox", "open Steam", "open Minecraft",
    "scroll down", "scroll up", "switch window", "close window",
    "new tab", "close tab", "search Google", "search YouTube",
    "check my email", "send an email", "check my calendar",
    "add an event", "clip that", "take a screenshot",
    "set a timer", "remind me", "set an alarm",
    "make a note", "what are my notes",
    "goodnight JARVIS", "wake up JARVIS",
    "what time is it", "what's the date",
    "lock my computer", "shut down", "restart",
    "play trivia", "play 20 questions", "play riddles",
    "copy", "paste", "zoom in", "zoom out",
    "go back", "go forward", "refresh",
    "what do you remember", "remember that",
    "send a discord message", "check discord",
]

CORRECTIONS = {
    # JARVIS name mishearings only
    r"\b(jarvice|jaw?vis|jarvy|jarvas|jar vis)\b": "jarvis",
    # Only correct "open desk" if it's exactly that — not if followed by other words
    r"\bopen desk\b(?! top)": "open desktop",
    # Clip mishearings
    r"\bclip (?:dad|dat)\b": "clip that",
    # Strip leading filler words Whisper/Google sometimes prepend
    r"^(?:um+|uh+)[,\.\s]+": "",
}

_whisper_model = None
_recognizer = None


def _get_recognizer():
    global _recognizer
    if _recognizer is None:
        import speech_recognition as sr
        _recognizer = sr.Recognizer()
        _recognizer.energy_threshold = 200
        _recognizer.dynamic_energy_threshold = False
    return _recognizer


def _get_whisper():
    global _whisper_model
    if _whisper_model is None:
        from faster_whisper import WhisperModel
        _whisper_model = WhisperModel(
            "small.en", device="cpu",
            compute_type="int8", cpu_threads=4
        )
    return _whisper_model


def warm_up():
    _get_recognizer()
    print("[stt] Ready.")


def _correct(text: str) -> str:
    t = text.strip()
    for pat, rep in CORRECTIONS.items():
        t = re.sub(pat, rep, t, flags=re.IGNORECASE)
    return t.strip()


def _save_wav(audio: np.ndarray, path: str):
    pcm = np.clip(audio * 32767, -32768, 32767).astype(np.int16)
    with wave.open(path, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SAMPLE_RATE)
        wf.writeframes(pcm.tobytes())


def record_fixed(seconds: float) -> np.ndarray:
    """Record for exactly N seconds. Simple and reliable."""
    frames = int(SAMPLE_RATE * seconds)
    audio = sd.rec(frames, samplerate=SAMPLE_RATE,
                   channels=1, dtype='float32')
    sd.wait()
    return audio.flatten()


def record_until_silence(max_seconds: float = 6.0) -> np.ndarray:
    """Fixed 3s recording - most reliable for short voice commands."""
    print("[stt] Listening...")
    audio = sd.rec(int(3 * SAMPLE_RATE), samplerate=SAMPLE_RATE,
                   channels=1, dtype="float32")
    sd.wait()
    result = audio.flatten()
    print(f"[stt] Recorded peak={np.max(np.abs(result)):.4f}")
    return result
    return np.concatenate(chunks)


def transcribe(audio: np.ndarray) -> str:
    """Transcribe audio array using Google STT with Whisper fallback."""
    if len(audio) < SAMPLE_RATE * 0.2:
        return ""

    # Apply gentle gain without hard clipping
    audio = audio.copy() * GAIN
    # Soft clip instead of hard normalize — preserves speech dynamics
    audio = np.tanh(audio) * 0.95

    # Try Google first
    try:
        import speech_recognition as sr
        r = _get_recognizer()

        tmp = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
        tmp.close()
        _save_wav(audio, tmp.name)

        with sr.AudioFile(tmp.name) as source:
            audio_data = r.record(source)
        os.unlink(tmp.name)

        # Use speech hints to boost JARVIS command accuracy
        text = r.recognize_google(
            audio_data,
            language="en-US",
            show_all=False,
        )
        result = _correct(text)
        print(f"[stt] Heard: '{result}'")
        return result

    except ImportError:
        pass
    except Exception as e:
        print(f"[stt] Google failed ({type(e).__name__}), trying Whisper...")

    # Whisper fallback
    try:
        model = _get_whisper()
        segs, _ = model.transcribe(
            audio, language="en", beam_size=5,
            temperature=0.0, vad_filter=True,
            condition_on_previous_text=False,
            initial_prompt="JARVIS voice command. Open desktop. What time is it. Check email.",
        )
        text = " ".join(s.text.strip() for s in segs).strip()
        result = _correct(text)
        print(f"[stt] Whisper: '{result}'")
        return result
    except Exception as e:
        print(f"[stt] Whisper failed: {e}")
        return ""


def transcribe_array(audio: np.ndarray) -> str:
    return transcribe(audio)


def listen_and_transcribe(seconds: float = 6.0) -> str:
    audio = record_until_silence(max_seconds=seconds)
    return transcribe(audio)


if __name__ == "__main__":
    print("JARVIS STT test — speak after the prompt (Ctrl+C to quit)\n")
    while True:
        try:
            print("Listening...")
            audio = record_until_silence(max_seconds=6.0)
            print(f"Recorded {len(audio)/SAMPLE_RATE:.1f}s")
            text = transcribe(audio)
            print(f'>>> "{text}"\n')
        except KeyboardInterrupt:
            break
