"""
JARVIS Notes & Memory
-----------------------
Persistent notes JARVIS remembers between sessions.
Stored in jarvis_notes.json in the same folder.

Commands:
    "make a note: buy milk"
    "remember that my wifi password is abc123"
    "what are my notes"
    "do I have any notes about passwords"
    "delete my note about milk"
"""

import json
import os
import re
from datetime import datetime

NOTES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "jarvis_notes.json")


def _load() -> list:
    if os.path.exists(NOTES_FILE):
        try:
            with open(NOTES_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return []


def _save(notes: list):
    with open(NOTES_FILE, "w") as f:
        json.dump(notes, f, indent=2)


def add_note(text: str) -> str:
    notes = _load()
    note = {
        "text": text.strip(),
        "created": datetime.now().strftime("%Y-%m-%d %H:%M")
    }
    notes.append(note)
    _save(notes)
    return f"Noted, sir: {text.strip()}"


def list_notes(query: str = None) -> str:
    notes = _load()
    if not notes:
        return "No notes saved yet, sir."

    if query:
        notes = [n for n in notes if query.lower() in n["text"].lower()]
        if not notes:
            return f"No notes found about {query}, sir."

    if len(notes) == 1:
        return f"One note, sir: {notes[0]['text']}"
    elif len(notes) <= 3:
        items = "; ".join(n["text"] for n in notes)
        return f"You have {len(notes)} notes: {items}."
    else:
        # Read the most recent 3
        recent = notes[-3:]
        items = "; ".join(n["text"] for n in recent)
        return f"You have {len(notes)} notes. Most recent: {items}."


def delete_note(query: str) -> str:
    notes = _load()
    original_count = len(notes)
    notes = [n for n in notes if query.lower() not in n["text"].lower()]
    if len(notes) == original_count:
        return f"No notes found about {query}, sir."
    _save(notes)
    removed = original_count - len(notes)
    return f"Removed {removed} note{'s' if removed != 1 else ''}, sir."


def clear_all_notes() -> str:
    _save([])
    return "All notes cleared, sir."


def parse_note_command(text: str) -> str | None:
    """Returns JARVIS response if this is a note command, else None."""
    t = text.lower().strip()

    # List notes
    if any(x in t for x in ["what are my notes", "list my notes",
                              "show my notes", "read my notes",
                              "do i have any notes"]):
        query = None
        for pat in [r"notes about (.+)", r"notes on (.+)"]:
            m = re.search(pat, t)
            if m:
                query = m.group(1).strip()
        return list_notes(query)

    # Delete note
    if any(x in t for x in ["delete note", "remove note",
                              "delete my note", "forget my note"]):
        m = re.search(r"(?:delete|remove|forget) (?:my )?note (?:about |on )?(.+)", t)
        if m:
            return delete_note(m.group(1).strip())
        return delete_note(t)

    # Clear all
    if any(x in t for x in ["clear all notes", "delete all notes",
                              "remove all notes"]):
        return clear_all_notes()

    # Add note
    for pat in [
        r"make a note[:\s]+(.+)",
        r"note[:\s]+(.+)",
        r"add a note[:\s]+(.+)",
        r"write (?:this )?down[:\s]+(.+)",
        r"jot (?:this )?down[:\s]+(.+)",
    ]:
        m = re.match(pat, t)
        if m:
            return add_note(m.group(1).strip())

    return None
