"""
JARVIS Fast Command Engine
----------------------------
For short known commands, fires the instant the phrase is complete —
no silence detection wait, no full Whisper transcription delay.

How it works:
    1. Audio streams in 80ms chunks (same as wake word)
    2. Every ~400ms we transcribe the accumulated buffer with Whisper tiny
    3. If the partial transcript matches a known short command, fire immediately
    4. Otherwise fall through to the normal full STT pipeline

This gives sub-second response on common commands while still handling
longer natural-language requests through the normal flow.
"""

import time
import threading
import numpy as np
import sounddevice as sd
from faster_whisper import WhisperModel

SAMPLE_RATE = 16000
CHUNK_SIZE = 1280          # 80ms chunks
CHECK_EVERY_CHUNKS = 5     # check for matches every ~400ms
MAX_CHUNKS = 75            # ~6 seconds max before giving up

# Short model just for fast matching - tiny is plenty for short phrases
_fast_model = None
_fast_lock = threading.Lock()


def _get_fast_model():
    global _fast_model
    with _fast_lock:
        if _fast_model is None:
            _fast_model = WhisperModel("tiny", device="cpu", compute_type="int8")
    return _fast_model


def _quick_transcribe(audio: np.ndarray) -> str:
    """Transcribes quickly with tiny model, no beam search overhead."""
    model = _get_fast_model()
    segs, _ = model.transcribe(
        audio.astype(np.float32) / 32768.0,
        language="en", beam_size=1, best_of=1,
        vad_filter=False,
        condition_on_previous_text=False,
    )
    return " ".join(s.text.strip() for s in segs).strip().lower()


# Commands that should fire instantly when heard - exact or close match
# Keys are what to listen for, values are the canonical command string
INSTANT_COMMANDS = {
    # Desktop / HUD
    "open desktop": "open desktop",
    "open my desktop": "open desktop",
    "show desktop": "open desktop",
    "hide jarvis": "open desktop",
    "open hud": "open hud",
    "show hud": "open hud",
    "bring back jarvis": "open hud",
    # Time / date
    "what time is it": "what time is it",
    "what's the time": "what time is it",
    "what day is it": "what's the date",
    "what's the date": "what's the date",
    # Window control
    "close window": "close window",
    "close this": "close window",
    "switch window": "switch window",
    "alt tab": "switch window",
    # Scroll
    "scroll down": "scroll down",
    "scroll up": "scroll up",
    # Media
    "pause": "pause music",
    "play": "play music",
    "next song": "next song",
    "skip song": "next song",
    # PC
    "lock computer": "lock computer",
    "lock my computer": "lock computer",
    # Sleep
    "goodnight jarvis": "goodnight jarvis",
    "good night jarvis": "goodnight jarvis",
    "wake up jarvis": "wake up jarvis",
    # Screenshot
    "screenshot": "take a screenshot",
    "take a screenshot": "take a screenshot",
    # Clip / Medal
    "clip that": "clip that",
    "save that clip": "clip that",
    "save clip": "clip that",
    "clip it": "clip that",
    "medal clip": "clip that",
    "clip this": "clip that",
    # Copy/paste
    "copy that": "copy",
    "paste that": "paste",
}


def _match(transcript: str) -> str | None:
    """Returns canonical command if transcript matches, else None."""
    t = transcript.lower().strip()
    # Strip leading filler words Whisper sometimes adds
    for filler in ["um ", "uh ", "okay ", "so ", "jarvis ", "hey jarvis "]:
        if t.startswith(filler):
            t = t[len(filler):]
    for phrase, canonical in INSTANT_COMMANDS.items():
        if phrase in t or t in phrase:
            return canonical
    return None


def listen_fast(on_instant_command, on_full_audio):
    """
    Streams microphone audio.
    - If a known short command is detected mid-stream: calls on_instant_command(canonical)
      immediately and stops listening.
    - If no match after MAX_CHUNKS: calls on_full_audio(audio_array) so the
      normal Whisper pipeline can handle it.

    Both callbacks should be non-blocking (start a thread if needed).
    """
    chunks = []
    check_counter = 0
    fired = False

    def callback(indata, frames, time_info, status):
        nonlocal check_counter, fired
        if fired:
            return
        chunks.append(indata[:, 0].copy().astype(np.int16))
        check_counter += 1

        if check_counter >= CHECK_EVERY_CHUNKS:
            check_counter = 0
            # Transcribe what we have so far
            audio_so_far = np.concatenate(chunks).astype(np.float32) / 32768.0
            if len(audio_so_far) < SAMPLE_RATE * 0.3:
                return  # too short to bother
            partial = _quick_transcribe(
                (audio_so_far * 32768).astype(np.int16)
            )
            if partial:
                match = _match(partial)
                if match:
                    fired = True
                    threading.Thread(
                        target=on_instant_command, args=(match,), daemon=True
                    ).start()

    with sd.InputStream(
        samplerate=SAMPLE_RATE, blocksize=CHUNK_SIZE,
        channels=1, dtype="int16", latency="high",
        callback=callback,
    ):
        start = time.time()
        while not fired and len(chunks) < MAX_CHUNKS:
            time.sleep(0.02)
            if time.time() - start > 6.0:
                break

    if not fired and chunks:
        # No instant match - pass full audio to normal STT pipeline
        full_audio = np.concatenate(chunks).astype(np.float32) / 32768.0
        on_full_audio(full_audio)
