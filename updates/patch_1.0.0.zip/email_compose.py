"""
JARVIS Voice Email Composer
-------------------------------
A guided, multi-turn voice flow: JARVIS asks who to email, what the
subject is, and what the body should say - then reads it all back and
asks for confirmation before actually sending anything. Sending an
email is hard to undo, so this deliberately does NOT send on a single
misheard phrase.

Usage:
    from email_compose import compose_and_send_email
    compose_and_send_email()   # runs the whole voice flow

Requires: stt.py, tts.py, email_client.py, contacts.py all present.
"""

from stt import listen_and_transcribe
from tts import speak
from email_client import send_email
from contacts import lookup_contact, parse_spoken_email

try:
    from orb_overlay import signals as orb_signals
    def _live(title, body): orb_signals.show_live_text.emit(title, body)
except ImportError:
    def _live(title, body): pass


def _confirm(prompt: str) -> bool:
    """Asks a yes/no question out loud and listens for the answer."""
    speak(prompt)
    answer = listen_and_transcribe(seconds=3).lower()
    return any(word in answer for word in ["yes", "yeah", "correct", "send", "confirm"])


def compose_and_send_email() -> str:
    # --- Recipient ---
    speak("Who would you like to email?")
    _live("Email", "Who to send to...")
    name_text = listen_and_transcribe(seconds=3)
    if not name_text:
        return "I didn't catch a name, sir. Cancelling."
    _live("Email · To", name_text)

    recipient = lookup_contact(name_text)
    if not recipient:
        recipient = parse_spoken_email(name_text)
        speak(f"I don't have {name_text} in your contacts. I'll try {recipient}. Say yes to continue.")
        _live("Email · To", f"{name_text} → {recipient}")
        answer = listen_and_transcribe(seconds=3).lower()
        if not any(w in answer for w in ["yes", "yeah", "correct", "continue"]):
            return "Cancelled."

    speak("What should the subject be?")
    _live("Email · Subject", "Listening...")
    subject = listen_and_transcribe(seconds=4)
    if not subject:
        return "I didn't catch a subject, sir. Cancelling."
    _live("Email · Subject", subject)

    speak("Go ahead and dictate the message.")
    _live("Email · Message", "Listening...")
    body = listen_and_transcribe(seconds=7)
    if not body:
        return "I didn't catch a message, sir. Cancelling."
    _live("Email · Message", body)
    if not body:
        return "I didn't catch a message, sir. Cancelling."

    # --- Confirm before sending ---
    confirmed = _confirm(
        f"Here's what I have. To: {recipient}. Subject: {subject}. "
        f"Message: {body}. Should I send it?"
    )

    if not confirmed:
        return "Okay, I won't send that."

    result = send_email(to=recipient, subject=subject, body=body)
    return result


if __name__ == "__main__":
    print(compose_and_send_email())
