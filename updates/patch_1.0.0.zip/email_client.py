"""
JARVIS Email Module (Gmail via IMAP/SMTP)
---------------------------------------------
Reads and sends email using your Gmail account - free, no third-party
API, using an App Password (see setup steps you were given separately).

SETUP REQUIRED before this works:
    1. Create a file named ".env" in this same folder (next to this
       script) with exactly these two lines, filled in with your info:

           GMAIL_ADDRESS=youraddress@gmail.com
           GMAIL_APP_PASSWORD=abcdefghijklmnop

       (The app password is the 16-character one from Google, no
       spaces - if Google showed it with spaces, remove them.)

    2. pip install python-dotenv

Usage:
    python email_client.py
    -> prints your 5 most recent unread email subjects

To use it from other modules:
    from email_client import check_recent_emails, send_email
"""

import os
import smtplib
import imaplib
import email as email_lib
from email.mime.text import MIMEText
from email.header import decode_header
from dotenv import load_dotenv

load_dotenv()  # reads the .env file in this folder

GMAIL_ADDRESS = os.getenv("GMAIL_ADDRESS")
GMAIL_APP_PASSWORD = os.getenv("GMAIL_APP_PASSWORD")

IMAP_SERVER = "imap.gmail.com"
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587


def _check_credentials():
    if not GMAIL_ADDRESS or not GMAIL_APP_PASSWORD:
        raise RuntimeError(
            "Gmail credentials not found. Create a .env file in this folder "
            "with GMAIL_ADDRESS and GMAIL_APP_PASSWORD - see the top of "
            "email_client.py for the exact format."
        )


def _decode_subject(raw_subject: str) -> str:
    decoded, encoding = decode_header(raw_subject)[0]
    if isinstance(decoded, bytes):
        return decoded.decode(encoding or "utf-8", errors="ignore")
    return decoded


def check_recent_emails(count: int = 5, unread_only: bool = True) -> list[dict]:
    """
    Returns a list of dicts: [{"from": ..., "subject": ...}, ...]
    for the most recent emails.
    """
    _check_credentials()

    mail = imaplib.IMAP4_SSL(IMAP_SERVER)
    mail.login(GMAIL_ADDRESS, GMAIL_APP_PASSWORD)
    mail.select("inbox")

    search_criteria = "UNSEEN" if unread_only else "ALL"
    status, data = mail.search(None, search_criteria)
    ids = data[0].split()
    ids = ids[-count:]  # most recent N
    ids.reverse()  # newest first

    results = []
    for eid in ids:
        status, msg_data = mail.fetch(eid, "(RFC822)")
        raw_email = msg_data[0][1]
        msg = email_lib.message_from_bytes(raw_email)
        subject = _decode_subject(msg.get("Subject", "(no subject)"))
        sender = msg.get("From", "(unknown sender)")
        results.append({"from": sender, "subject": subject})

    mail.logout()
    return results


def send_email(to: str, subject: str, body: str) -> str:
    """Sends a plain-text email. Returns a status message."""
    _check_credentials()

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = GMAIL_ADDRESS
    msg["To"] = to

    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(GMAIL_ADDRESS, GMAIL_APP_PASSWORD)
            server.sendmail(GMAIL_ADDRESS, [to], msg.as_string())
        return f"Email sent to {to}."
    except Exception as e:
        return f"Failed to send email: {e}"


if __name__ == "__main__":
    print("Checking your 5 most recent unread emails...\n")
    try:
        emails = check_recent_emails(count=5)
        if not emails:
            print("No unread emails.")
        for i, e in enumerate(emails, 1):
            print(f"{i}. From: {e['from']}")
            print(f"   Subject: {e['subject']}\n")
    except Exception as ex:
        print(f"Error: {ex}")
