"""
JARVIS Medal Integration
--------------------------
Triggers Medal's clip hotkey via keyboard shortcut.

Medal records your screen continuously in a rolling buffer (like the last
30/60/120 seconds depending on your settings). When you say "clip that",
JARVIS presses the Medal hotkey to save whatever was just recorded.

DEFAULT MEDAL HOTKEY: F8
(You can change this below if you've customized it in Medal's settings)

To verify/change your Medal hotkey:
    Open Medal -> Settings -> Clips -> Clip Hotkey
    Whatever key is shown there, put it in MEDAL_HOTKEY below.

JARVIS trigger phrases:
    "clip that"
    "save that clip"
    "medal clip"
    "save clip"
    "clip the last [X] seconds"  (just triggers clip - Medal uses its buffer length)
"""

import time
import pyautogui

# Change this to match your Medal hotkey setting
MEDAL_HOTKEY = "f8"

# If your Medal hotkey is a combo like Ctrl+F8, use:
# MEDAL_HOTKEY = ("ctrl", "f8")


def trigger_clip() -> str:
    """Presses the Medal clip hotkey to save the current buffer as a clip."""
    try:
        if isinstance(MEDAL_HOTKEY, tuple):
            pyautogui.hotkey(*MEDAL_HOTKEY)
        else:
            pyautogui.press(MEDAL_HOTKEY)
        time.sleep(0.2)
        return "Clip saved, sir."
    except Exception as e:
        return f"Couldn't trigger Medal. Make sure Medal is running. ({e})"


def is_clip_command(text: str) -> bool:
    """Returns True if the spoken text is a clip command."""
    t = text.lower()
    return any(x in t for x in [
        "clip that", "save that clip", "save clip",
        "medal clip", "clip it", "clip the last",
        "save that", "record that", "save the clip",
        "clip this", "save this clip",
    ])


if __name__ == "__main__":
    print("Testing Medal clip trigger in 3 seconds...")
    print(f"Make sure Medal is running and your hotkey is set to: {MEDAL_HOTKEY}")
    time.sleep(3)
    print(trigger_clip())
