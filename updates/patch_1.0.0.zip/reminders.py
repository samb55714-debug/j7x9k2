"""
JARVIS Timers, Alarms & Reminders
------------------------------------
Voice-triggered timers and reminders that fire even while JARVIS is
doing other things. All run in background threads.

Commands:
    "set a timer for 5 minutes"
    "remind me to call mum in 20 minutes"
    "set an alarm for 7am"
    "what timers do I have"
    "cancel my timer"
"""

import threading
import time
import re
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

CENTRAL = ZoneInfo("America/Chicago")

# Callback called when a timer/reminder fires — set this to JARVIS's speak function
_fire_callback = None
_active_timers = {}   # name -> threading.Timer
_timer_lock = threading.Lock()
_timer_counter = [0]


def set_fire_callback(fn):
    """Set the function JARVIS calls when a timer fires. Should be speak_with_orb."""
    global _fire_callback
    _fire_callback = fn


def _fire(name: str, message: str):
    with _timer_lock:
        _active_timers.pop(name, None)
    print(f"[reminders] FIRED: {name} - {message}")
    if _fire_callback:
        _fire_callback(message)
    else:
        print(f"REMINDER: {message}")


def set_timer(seconds: float, label: str = None) -> str:
    with _timer_lock:
        _timer_counter[0] += 1
        name = label or f"timer_{_timer_counter[0]}"
        message = f"Timer complete, sir. {label + ' is done.' if label else 'Your timer has finished.'}"

        t = threading.Timer(seconds, _fire, args=[name, message])
        t.daemon = True
        t.start()
        _active_timers[name] = (t, time.time() + seconds, message)

    mins = int(seconds // 60)
    secs = int(seconds % 60)
    if mins > 0 and secs > 0:
        duration = f"{mins} minute{'s' if mins != 1 else ''} and {secs} seconds"
    elif mins > 0:
        duration = f"{mins} minute{'s' if mins != 1 else ''}"
    else:
        duration = f"{secs} second{'s' if secs != 1 else ''}"

    return f"Timer set for {duration}, sir."


def set_reminder(seconds: float, reminder_text: str) -> str:
    with _timer_lock:
        _timer_counter[0] += 1
        name = f"reminder_{_timer_counter[0]}"
        message = f"Reminder, sir: {reminder_text}"
        t = threading.Timer(seconds, _fire, args=[name, message])
        t.daemon = True
        t.start()
        _active_timers[name] = (t, time.time() + seconds, message)

    mins = int(seconds // 60)
    return f"I'll remind you to {reminder_text} in {mins} minute{'s' if mins != 1 else ''}, sir."


def list_timers() -> str:
    with _timer_lock:
        if not _active_timers:
            return "No active timers or reminders, sir."
        lines = []
        now = time.time()
        for name, (t, fire_at, msg) in _active_timers.items():
            remaining = max(0, fire_at - now)
            mins = int(remaining // 60)
            secs = int(remaining % 60)
            lines.append(f"{name}: {mins}m {secs}s remaining")
        return "Active timers: " + ", ".join(lines) + "."


def cancel_timer(name: str = None) -> str:
    with _timer_lock:
        if not _active_timers:
            return "No active timers to cancel, sir."
        if name and name in _active_timers:
            _active_timers[name][0].cancel()
            del _active_timers[name]
            return f"Timer '{name}' cancelled, sir."
        # Cancel most recent
        last_name = list(_active_timers.keys())[-1]
        _active_timers[last_name][0].cancel()
        del _active_timers[last_name]
        return f"Most recent timer cancelled, sir."


def cancel_all_timers() -> str:
    with _timer_lock:
        count = len(_active_timers)
        for name, (t, _, _) in _active_timers.items():
            t.cancel()
        _active_timers.clear()
    return f"All {count} timer{'s' if count != 1 else ''} cancelled, sir."


def set_alarm(hour: int, minute: int, label: str = "alarm") -> str:
    """Sets an alarm for a specific time today (or tomorrow if already past)."""
    now = datetime.now(CENTRAL)
    alarm_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if alarm_time <= now:
        alarm_time += timedelta(days=1)
    seconds = (alarm_time - now).total_seconds()
    period = "AM" if hour < 12 else "PM"
    display_hour = hour if hour <= 12 else hour - 12
    if display_hour == 0:
        display_hour = 12
    return set_timer(seconds, f"Alarm: {display_hour}:{minute:02d} {period}")


# ---------------------------------------------------------------------------
# Natural language parser
# ---------------------------------------------------------------------------
def parse_timer_command(text: str) -> str | None:
    """
    Parses natural language timer/reminder commands.
    Returns JARVIS's response string, or None if not a timer command.
    """
    t = text.lower().strip()

    # List timers
    if any(x in t for x in ["what timers", "list timers", "my timers",
                              "active timers", "any timers"]):
        return list_timers()

    # Cancel
    if any(x in t for x in ["cancel timer", "cancel my timer",
                              "stop timer", "cancel all timers"]):
        if "all" in t:
            return cancel_all_timers()
        return cancel_timer()

    # Alarm: "set an alarm for 7am" / "alarm at 7:30 pm"
    alarm_pat = re.search(
        r"(?:set (?:an )?alarm|alarm) (?:for |at )?(\d{1,2})(?::(\d{2}))?\s*(am|pm)?",
        t
    )
    if alarm_pat:
        hour = int(alarm_pat.group(1))
        minute = int(alarm_pat.group(2) or 0)
        period = alarm_pat.group(3) or ""
        if period == "pm" and hour != 12:
            hour += 12
        elif period == "am" and hour == 12:
            hour = 0
        return set_alarm(hour, minute)

    # Reminder: "remind me to X in N minutes"
    remind_pat = re.search(
        r"remind me (?:to (.+?) )?in (\d+)\s*(second|minute|hour|min|sec|hr)s?",
        t
    )
    if remind_pat:
        task = remind_pat.group(1) or "do that"
        amount = int(remind_pat.group(2))
        unit = remind_pat.group(3)
        if unit in ("second", "sec"):
            seconds = amount
        elif unit in ("hour", "hr"):
            seconds = amount * 3600
        else:
            seconds = amount * 60
        return set_reminder(seconds, task)

    # Timer: "set a timer for N minutes/seconds/hours"
    timer_pat = re.search(
        r"(?:set (?:a )?timer|timer) (?:for )?(\d+)\s*(second|minute|hour|min|sec|hr)s?",
        t
    )
    if timer_pat:
        amount = int(timer_pat.group(1))
        unit = timer_pat.group(2)
        if unit in ("second", "sec"):
            seconds = amount
        elif unit in ("hour", "hr"):
            seconds = amount * 3600
        else:
            seconds = amount * 60
        return set_timer(seconds)

    # Simple: "5 minute timer" / "30 second timer"
    simple_pat = re.search(
        r"(\d+)\s*(second|minute|hour|min|sec|hr)s?\s*timer",
        t
    )
    if simple_pat:
        amount = int(simple_pat.group(1))
        unit = simple_pat.group(2)
        if unit in ("second", "sec"):
            seconds = amount
        elif unit in ("hour", "hr"):
            seconds = amount * 3600
        else:
            seconds = amount * 60
        return set_timer(seconds)

    return None
