"""
JARVIS Browser Control v2
- All searches use direct URL navigation (no keyboard typing into address bar)
- Opens Chrome directly if not running
- Reliable new tab + navigation via subprocess
"""

import subprocess
import time
import urllib.parse
import webbrowser


def _chrome_url(url: str):
    """Opens a URL in Chrome directly - most reliable method."""
    try:
        import glob, os
        chrome_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
        for path in chrome_paths:
            if os.path.exists(path):
                subprocess.Popen([path, url],
                                 creationflags=subprocess.DETACHED_PROCESS)
                return True
    except Exception:
        pass
    # Fallback to default browser
    webbrowser.open(url)
    return True


def new_tab(url: str = "about:newtab"):
    _chrome_url(url)
    time.sleep(0.8)


def close_tab():
    import pyautogui
    pyautogui.hotkey("ctrl", "w")


def navigate(url: str):
    if not url.startswith("http"):
        url = "https://" + url
    _chrome_url(url)
    time.sleep(1.0)


def search_google(query: str):
    encoded = urllib.parse.quote(query)
    _chrome_url(f"https://www.google.com/search?q={encoded}")
    time.sleep(1.5)


def search_youtube(query: str):
    encoded = urllib.parse.quote(query)
    _chrome_url(f"https://www.youtube.com/results?search_query={encoded}")
    time.sleep(1.5)


def click_first_result():
    import pyautogui
    time.sleep(0.5)
    pyautogui.hotkey("ctrl", "l")
    time.sleep(0.2)
    pyautogui.press("escape")
    time.sleep(0.2)
    pyautogui.press("tab")
    time.sleep(0.1)
    pyautogui.press("enter")
    time.sleep(1.0)


def click_top_youtube_result():
    import pyautogui
    time.sleep(1.0)
    pyautogui.hotkey("ctrl", "l")
    time.sleep(0.2)
    pyautogui.press("escape")
    time.sleep(0.2)
    for _ in range(6):
        pyautogui.press("tab")
        time.sleep(0.05)
    pyautogui.press("enter")
    time.sleep(1.0)


def go_back():
    import pyautogui
    pyautogui.hotkey("alt", "left")


def go_forward():
    import pyautogui
    pyautogui.hotkey("alt", "right")


def next_tab():
    import pyautogui
    pyautogui.hotkey("ctrl", "tab")


def prev_tab():
    import pyautogui
    pyautogui.hotkey("ctrl", "shift", "tab")


def zoom_in():
    import pyautogui
    pyautogui.hotkey("ctrl", "equal")


def zoom_out():
    import pyautogui
    pyautogui.hotkey("ctrl", "minus")


def refresh():
    import pyautogui
    pyautogui.press("f5")


def search_in_page(query: str):
    import pyautogui
    pyautogui.hotkey("ctrl", "f")
    time.sleep(0.3)
    pyautogui.write(query, interval=0.03)
