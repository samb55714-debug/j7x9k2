"""
JARVIS Media Control Module
Controls media playback via Windows media keys - works with Spotify,
YouTube, VLC, Windows Media Player, or any media app.
"""
import pyautogui
import subprocess

def play_pause():
    pyautogui.press("playpause")
    return "Toggled playback."

def next_track():
    pyautogui.press("nexttrack")
    return "Next track."

def prev_track():
    pyautogui.press("prevtrack")
    return "Previous track."

def volume_up(steps: int = 5):
    for _ in range(steps):
        pyautogui.press("volumeup")
    return f"Volume up."

def volume_down(steps: int = 5):
    for _ in range(steps):
        pyautogui.press("volumedown")
    return f"Volume down."

def mute():
    pyautogui.press("volumemute")
    return "Toggled mute."

def stop():
    pyautogui.press("stop")
    return "Stopped."

if __name__ == "__main__":
    print("Testing media keys...")
    print(volume_up(2))
