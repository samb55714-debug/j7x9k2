"""
JARVIS Math, Conversions & Quick Facts Module
"""
import re
import math

def calculate(expression: str) -> str:
    """Safely evaluates a math expression from voice."""
    # Clean up spoken math
    expr = expression.lower()
    expr = expr.replace("plus", "+").replace("minus", "-")
    expr = expr.replace("times", "*").replace("multiplied by", "*")
    expr = expr.replace("divided by", "/").replace("over", "/")
    expr = expr.replace("squared", "**2").replace("cubed", "**3")
    expr = expr.replace("percent", "/100")
    expr = re.sub(r"[^0-9\+\-\*\/\.\(\)\%\*]", "", expr)

    try:
        result = eval(expr, {"__builtins__": {}}, {
            "sqrt": math.sqrt, "pi": math.pi, "sin": math.sin,
            "cos": math.cos, "tan": math.tan, "log": math.log,
            "abs": abs, "round": round,
        })
        if isinstance(result, float) and result.is_integer():
            result = int(result)
        return f"The answer is {result}."
    except Exception:
        return f"I couldn't calculate that, sir."

CONVERSIONS = {
    # Length
    ("miles", "kilometers"): lambda x: x * 1.60934,
    ("kilometers", "miles"): lambda x: x / 1.60934,
    ("feet", "meters"): lambda x: x * 0.3048,
    ("meters", "feet"): lambda x: x / 0.3048,
    ("inches", "centimeters"): lambda x: x * 2.54,
    ("centimeters", "inches"): lambda x: x / 2.54,
    # Weight
    ("pounds", "kilograms"): lambda x: x * 0.453592,
    ("kilograms", "pounds"): lambda x: x / 0.453592,
    ("ounces", "grams"): lambda x: x * 28.3495,
    ("grams", "ounces"): lambda x: x / 28.3495,
    # Temperature
    ("celsius", "fahrenheit"): lambda x: x * 9/5 + 32,
    ("fahrenheit", "celsius"): lambda x: (x - 32) * 5/9,
    # Volume
    ("gallons", "liters"): lambda x: x * 3.78541,
    ("liters", "gallons"): lambda x: x / 3.78541,
}

def convert(amount: float, from_unit: str, to_unit: str) -> str:
    key = (from_unit.lower().rstrip("s"), to_unit.lower().rstrip("s"))
    # Try with and without trailing s
    fn = None
    for k, v in CONVERSIONS.items():
        if (k[0] in from_unit.lower() and k[1] in to_unit.lower()):
            fn = v
            break
    if not fn:
        return f"I don't know how to convert {from_unit} to {to_unit}, sir."
    result = fn(amount)
    return f"{amount} {from_unit} is {result:.2f} {to_unit}."

def parse_and_convert(text: str) -> str:
    """Parses a conversion phrase like '5 miles to kilometers'."""
    m = re.search(r"([\d\.]+)\s+(\w+)\s+(?:to|in|into)\s+(\w+)", text.lower())
    if m:
        amount = float(m.group(1))
        from_u = m.group(2)
        to_u = m.group(3)
        return convert(amount, from_u, to_u)
    return "I didn't catch the conversion, sir. Try saying something like '5 miles to kilometers'."

if __name__ == "__main__":
    print(calculate("25 times 4 plus 10"))
    print(parse_and_convert("10 miles to kilometers"))
    print(parse_and_convert("100 fahrenheit to celsius"))
