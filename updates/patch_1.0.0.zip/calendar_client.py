"""
JARVIS Calendar Module (Google Calendar API)
"""

import os
import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ["https://www.googleapis.com/auth/calendar"]
HERE = os.path.dirname(os.path.abspath(__file__))
CREDENTIALS_FILE = os.path.join(HERE, "credentials.json")
TOKEN_FILE = os.path.join(HERE, "token.json")


def _get_service():
    creds = None
    if os.path.exists(TOKEN_FILE):
        creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
                with open(TOKEN_FILE, "w") as f:
                    f.write(creds.to_json())
            except Exception:
                # Token revoked or expired beyond refresh — delete and re-auth
                if os.path.exists(TOKEN_FILE):
                    os.remove(TOKEN_FILE)
                creds = None

        if not creds:
            if not os.path.exists(CREDENTIALS_FILE):
                raise RuntimeError(
                    "credentials.json not found. See the top of calendar_client.py for setup."
                )
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
            with open(TOKEN_FILE, "w") as f:
                f.write(creds.to_json())

    return build("calendar", "v3", credentials=creds)


def get_upcoming_events(count: int = 5) -> list[dict]:
    service = _get_service()
    now = datetime.datetime.utcnow().isoformat() + "Z"
    events_result = (
        service.events()
        .list(
            calendarId="primary",
            timeMin=now,
            maxResults=count,
            singleEvents=True,
            orderBy="startTime",
        )
        .execute()
    )
    events = events_result.get("items", [])
    results = []
    for event in events:
        start = event["start"].get("dateTime", event["start"].get("date"))
        results.append({"summary": event.get("summary", "(no title)"), "start": start})
    return results


def create_event(summary: str, start_dt: datetime.datetime, duration_minutes: int = 60) -> str:
    service = _get_service()
    end_dt = start_dt + datetime.timedelta(minutes=duration_minutes)
    event = {
        "summary": summary,
        "start": {"dateTime": start_dt.isoformat(), "timeZone": "America/Chicago"},
        "end": {"dateTime": end_dt.isoformat(), "timeZone": "America/Chicago"},
    }
    try:
        service.events().insert(calendarId="primary", body=event).execute()
        return f"Added '{summary}' to your calendar for {start_dt.strftime('%A, %B %d at %I:%M %p')}."
    except Exception as e:
        return f"Failed to create event: {e}"


if __name__ == "__main__":
    print("Fetching your next 5 upcoming events...\n")
    try:
        events = get_upcoming_events(5)
        if not events:
            print("No upcoming events found.")
        for e in events:
            print(f"  {e['start']}: {e['summary']}")
    except Exception as ex:
        print(f"Error: {ex}")
