"""
JARVIS Auto-Updater
--------------------
Checks GitHub for new versions on startup.
Downloads only changed files (not the full zip).
Shows update progress in the orb GUI.

How it works:
1. On startup, fetches version.json from your GitHub repo
2. Compares version number to local version
3. If newer: downloads a patch.zip containing only changed files
4. Extracts and replaces them, then restarts JARVIS

Your GitHub repo structure needed:
    /updates/version.json      <- current version info
    /updates/patch_1.0.1.zip   <- changed files for each version

Setup:
    1. Set GITHUB_RAW_URL to your repo's raw content URL
    2. Run push_update.bat on your PC after changing files
"""

import os
import sys
import json
import zipfile
import shutil
import tempfile
import threading
import subprocess
import requests
from pathlib import Path

# ── CONFIG — change these to match your GitHub repo ─────────────────────────
GITHUB_RAW_URL = "https://raw.githubusercontent.com/samb55714-debug/j7x9k2/main/updates"
LOCAL_VERSION_FILE = Path(__file__).parent.parent / "version.json"
JARVIS_DIR = Path(__file__).parent.parent
CHECK_TIMEOUT = 5  # seconds to wait for GitHub before giving up
# ─────────────────────────────────────────────────────────────────────────────


def get_local_version() -> str:
    try:
        if LOCAL_VERSION_FILE.exists():
            data = json.loads(LOCAL_VERSION_FILE.read_text())
            return data.get("version", "0.0.0")
    except Exception:
        pass
    return "0.0.0"


def get_remote_version() -> dict | None:
    try:
        url = f"{GITHUB_RAW_URL}/version.json"
        r = requests.get(url, timeout=CHECK_TIMEOUT)
        if r.status_code == 200:
            return r.json()
    except Exception as e:
        print(f"[updater] Could not check for updates: {e}")
    return None


def _version_tuple(v: str) -> tuple:
    try:
        return tuple(int(x) for x in v.split("."))
    except Exception:
        return (0, 0, 0)


def is_update_available() -> tuple[bool, dict | None]:
    remote = get_remote_version()
    if not remote:
        return False, None
    local = get_local_version()
    if _version_tuple(remote["version"]) > _version_tuple(local):
        return True, remote
    return False, None


def download_and_apply_update(remote_info: dict,
                               progress_cb=None,
                               log_cb=None) -> bool:
    """
    Downloads the patch zip and applies it.
    progress_cb(0.0-1.0) for progress bar
    log_cb(str) for status messages
    """
    def log(msg):
        print(f"[updater] {msg}")
        if log_cb:
            log_cb(msg)

    def prog(val):
        if progress_cb:
            progress_cb(val)

    version = remote_info["version"]
    patch_url = f"{GITHUB_RAW_URL}/{remote_info['patch']}"

    log(f"Downloading update v{version}...")
    prog(0.1)

    try:
        # Download patch zip
        tmp_dir = Path(tempfile.mkdtemp())
        patch_path = tmp_dir / "patch.zip"

        r = requests.get(patch_url, stream=True, timeout=30)
        total = int(r.headers.get("content-length", 0))
        downloaded = 0

        with open(patch_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)
                downloaded += len(chunk)
                if total:
                    prog(0.1 + 0.6 * (downloaded / total))

        log("Applying update...")
        prog(0.75)

        # Extract patch
        extract_dir = tmp_dir / "patch"
        with zipfile.ZipFile(patch_path, "r") as zf:
            zf.extractall(extract_dir)

        # Copy files over the existing installation
        for item in extract_dir.rglob("*"):
            if item.is_file():
                rel = item.relative_to(extract_dir)
                dest = JARVIS_DIR / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, dest)
                log(f"  Updated: {rel}")

        prog(0.9)

        # Update local version file
        LOCAL_VERSION_FILE.write_text(json.dumps({
            "version": version,
            "updated": remote_info.get("date", ""),
            "notes": remote_info.get("notes", "")
        }, indent=2))

        # Cleanup
        shutil.rmtree(tmp_dir, ignore_errors=True)
        prog(1.0)
        log(f"✓ Updated to v{version} successfully")
        return True

    except Exception as e:
        log(f"✗ Update failed: {e}")
        return False


def check_and_update_background(on_update_available=None,
                                 on_update_complete=None,
                                 silent=True):
    """
    Runs the update check in a background thread.
    on_update_available(remote_info) — called if update found (can show dialog)
    on_update_complete(success) — called after update applied
    silent=True — applies updates without asking
    """
    def _run():
        available, remote = is_update_available()
        if not available:
            print(f"[updater] Up to date (v{get_local_version()})")
            return

        print(f"[updater] Update available: v{remote['version']}")

        if on_update_available:
            on_update_available(remote)

        if silent:
            success = download_and_apply_update(remote)
            if on_update_complete:
                on_update_complete(success)
            if success:
                restart_jarvis()

    t = threading.Thread(target=_run, daemon=True)
    t.start()


def restart_jarvis():
    """Restart JARVIS after an update."""
    print("[updater] Restarting JARVIS...")
    python = sys.executable
    script = JARVIS_DIR / "run_jarvis.py"
    subprocess.Popen([python, str(script)], cwd=str(JARVIS_DIR))
    sys.exit(0)


if __name__ == "__main__":
    print(f"Local version: {get_local_version()}")
    available, remote = is_update_available()
    if available:
        print(f"Update available: v{remote['version']}")
        print(f"Notes: {remote.get('notes', '')}")
    else:
        print("Already up to date.")
