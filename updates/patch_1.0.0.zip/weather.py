"""
JARVIS Weather Module (Open-Meteo - completely free, no API key)
"""
import requests
from datetime import datetime

# Your location - Dubuque, Iowa
LATITUDE = 42.5006
LONGITUDE = -90.6646
LOCATION_NAME = "Dubuque"

WMO_CODES = {
    0: "clear sky", 1: "mainly clear", 2: "partly cloudy", 3: "overcast",
    45: "foggy", 48: "icy fog", 51: "light drizzle", 53: "drizzle",
    55: "heavy drizzle", 61: "light rain", 63: "rain", 65: "heavy rain",
    71: "light snow", 73: "snow", 75: "heavy snow", 77: "snow grains",
    80: "rain showers", 81: "heavy showers", 82: "violent showers",
    85: "snow showers", 86: "heavy snow showers",
    95: "thunderstorm", 96: "thunderstorm with hail", 99: "severe thunderstorm",
}

def get_weather() -> str:
    try:
        r = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": LATITUDE, "longitude": LONGITUDE,
                "current": ["temperature_2m", "weathercode", "windspeed_10m",
                            "relativehumidity_2m", "apparent_temperature"],
                "temperature_unit": "fahrenheit",
                "windspeed_unit": "mph", "timezone": "America/Chicago",
            }, timeout=5)
        d = r.json()["current"]
        temp = round(d["temperature_2m"])
        feels = round(d["apparent_temperature"])
        condition = WMO_CODES.get(d["weathercode"], "unknown conditions")
        wind = round(d["windspeed_10m"])
        humidity = d["relativehumidity_2m"]
        return (f"Currently in {LOCATION_NAME}: {temp}°F, feels like {feels}°F, "
                f"{condition}, wind {wind} mph, humidity {humidity}%.")
    except Exception as e:
        return f"I couldn't fetch the weather right now. {e}"

def get_forecast() -> str:
    try:
        r = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": LATITUDE, "longitude": LONGITUDE,
                "daily": ["temperature_2m_max", "temperature_2m_min", "weathercode"],
                "temperature_unit": "fahrenheit",
                "timezone": "America/Chicago", "forecast_days": 3,
            }, timeout=5)
        d = r.json()["daily"]
        days = []
        for i in range(3):
            date = datetime.strptime(d["time"][i], "%Y-%m-%d").strftime("%A")
            hi = round(d["temperature_2m_max"][i])
            lo = round(d["temperature_2m_min"][i])
            cond = WMO_CODES.get(d["weathercode"][i], "mixed conditions")
            days.append(f"{date}: {cond}, high {hi}°F, low {lo}°F")
        return "3-day forecast for " + LOCATION_NAME + ". " + ". ".join(days) + "."
    except Exception as e:
        return f"I couldn't fetch the forecast right now. {e}"

if __name__ == "__main__":
    print(get_weather())
    print(get_forecast())
