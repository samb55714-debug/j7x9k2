"""
JARVIS Update Publisher
Run with: python push_update.py
No batch variables, no contamination issues.
"""

import os
import sys
import json
import shutil
import zipfile
import subprocess
from pathlib import Path
from datetime import date

JARVIS_DIR = Path.home() / "Downloads"
STAGING = Path(os.environ["TEMP"]) / "jv_clean_staging"
REPO_DIR = Path.home() / "Documents" / "jarvis-repo"
REPO_CONFIG = JARVIS_DIR / ".jarvis_repo_url"

print()
print("  ==========================================")
print("   JARVIS Update Publisher")
print("  ==========================================")
print()

# Get clean inputs
ver = input("  New version (e.g. 1.0.1): ").strip()
notes = input("  What changed: ").strip()
files_input = input("  Files changed (Enter for ALL): ").strip()

# Validate version - must be simple like 1.0.1
import re
if not re.match(r'^\d+\.\d+\.\d+$', ver):
    print(f"\n  [!] Bad version format '{ver}' - use numbers like 1.0.1")
    input("  Press Enter to exit...")
    sys.exit(1)

zip_name = f"patch_{ver}.zip"
zip_path = JARVIS_DIR / zip_name

print(f"\n  Building {zip_name}...")

# Clean staging
if STAGING.exists():
    shutil.rmtree(STAGING)
STAGING.mkdir(parents=True)
(STAGING / "core").mkdir()

# Copy files
if not files_input:
    # All files
    for f in JARVIS_DIR.glob("*.py"):
        shutil.copy2(f, STAGING / f.name)
    core_dir = JARVIS_DIR / "core"
    if core_dir.exists():
        for f in core_dir.glob("*.py"):
            shutil.copy2(f, STAGING / "core" / f.name)
    print(f"  Packaged all Python files")
else:
    for fname in files_input.split():
        src = JARVIS_DIR / fname
        dst = STAGING / Path(fname).name
        if src.exists():
            shutil.copy2(src, dst)
            print(f"  Added: {fname}")
        else:
            print(f"  [!] Not found: {fname}")

# Create zip
if zip_path.exists():
    zip_path.unlink()

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for f in STAGING.rglob("*"):
        if f.is_file():
            zf.write(f, f.relative_to(STAGING))

print(f"  Created: {zip_name} ({zip_path.stat().st_size // 1024}KB)")

# Write version.json
version_data = {
    "version": ver,
    "date": str(date.today()),
    "notes": notes,
    "patch": zip_name
}
version_path = JARVIS_DIR / "version.json"
version_path.write_text(json.dumps(version_data, indent=2))
print(f"  version.json updated")

# Push to GitHub
print(f"\n  Pushing to GitHub...")

# Check git
try:
    subprocess.run(["git", "--version"], capture_output=True, check=True)
except (subprocess.CalledProcessError, FileNotFoundError):
    print("  [!] Git not found. Install from git-scm.com")
    print(f"\n  Manually upload these to your GitHub /updates/ folder:")
    print(f"    {version_path}")
    print(f"    {zip_path}")
    input("\n  Press Enter to exit...")
    sys.exit(1)

# Get or ask for repo URL
if REPO_CONFIG.exists():
    repo_url = REPO_CONFIG.read_text().strip()
    print(f"  Using repo: {repo_url}")
else:
    repo_url = input("  Paste your GitHub repo URL: ").strip()
    REPO_CONFIG.write_text(repo_url)

# Clone if needed
if not (REPO_DIR / ".git").exists():
    print("  Cloning repo (first time)...")
    result = subprocess.run(
        ["git", "clone", repo_url, str(REPO_DIR)],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        print(f"  [!] Clone failed: {result.stderr}")
        input("  Press Enter to exit...")
        sys.exit(1)

# Copy files into repo
updates_dir = REPO_DIR / "updates"
updates_dir.mkdir(exist_ok=True)
shutil.copy2(version_path, updates_dir / "version.json")
shutil.copy2(zip_path, updates_dir / zip_name)

# Git commit and push
os.chdir(REPO_DIR)
subprocess.run(["git", "add", "updates/"])
subprocess.run(["git", "commit", "-m", f"v{ver} - {notes}"])
result = subprocess.run(["git", "push"], capture_output=True, text=True)

if result.returncode != 0:
    print(f"  [!] Push failed: {result.stderr}")
    print("  You may need to log into GitHub first.")
else:
    print()
    print("  ==========================================")
    print(f"   v{ver} is live!")
    print(f"   All copies update on next startup.")
    print("  ==========================================")

# Cleanup
shutil.rmtree(STAGING, ignore_errors=True)
print()
input("  Press Enter to close...")
