"""
JARVIS Audio Ducking
---------------------
Reduces all other system audio while JARVIS is speaking,
then restores it afterward. Uses Windows Core Audio API via pycaw.

Install: pip install pycaw comtypes

How it works:
- Before JARVIS speaks: lowers all other app volumes to DUCK_LEVEL
- After JARVIS speaks: restores them to original levels
- JARVIS's own audio output is excluded from ducking
"""

import time

DUCK_LEVEL = 0.08    # 8% volume while JARVIS speaks (nearly silent)
FADE_STEPS = 8       # number of steps for smooth fade in/out
FADE_DELAY = 0.02    # seconds between fade steps

_session_volumes = {}  # store original volumes to restore later
_pycaw_available = False

try:
    from pycaw.pycaw import AudioUtilities, ISimpleAudioVolume
    import comtypes
    _pycaw_available = True
except ImportError:
    pass


def _get_sessions():
    """Get all active audio sessions except JARVIS itself."""
    if not _pycaw_available:
        return []
    try:
        sessions = AudioUtilities.GetAllSessions()
        result = []
        for session in sessions:
            if session.Process and session.Process.name().lower() not in (
                "python.exe", "python3.exe",  # exclude JARVIS's own process
            ):
                vol = session._ctl.QueryInterface(ISimpleAudioVolume)
                result.append((session.Process.name(), vol))
        return result
    except Exception:
        return []


def duck():
    """Lower all other app audio. Call this just before JARVIS speaks."""
    if not _pycaw_available:
        return

    global _session_volumes
    _session_volumes = {}

    try:
        sessions = _get_sessions()
        for name, vol in sessions:
            try:
                original = vol.GetMasterVolume()
                _session_volumes[vol] = original

                # Smooth fade down
                current = original
                step = (current - DUCK_LEVEL) / FADE_STEPS
                for _ in range(FADE_STEPS):
                    current = max(DUCK_LEVEL, current - step)
                    vol.SetMasterVolume(current, None)
                    time.sleep(FADE_DELAY)
            except Exception:
                pass
    except Exception as e:
        print(f"[audio_duck] Duck error: {e}")


def unduck():
    """Restore all other app audio. Call this after JARVIS finishes speaking."""
    if not _pycaw_available or not _session_volumes:
        return

    try:
        for vol, original in _session_volumes.items():
            try:
                # Smooth fade back up
                current = DUCK_LEVEL
                step = (original - current) / FADE_STEPS
                for _ in range(FADE_STEPS):
                    current = min(original, current + step)
                    vol.SetMasterVolume(current, None)
                    time.sleep(FADE_DELAY)
                # Make sure we land exactly on original
                vol.SetMasterVolume(original, None)
            except Exception:
                pass
        _session_volumes.clear()
    except Exception as e:
        print(f"[audio_duck] Unduck error: {e}")


def is_available() -> bool:
    return _pycaw_available


if __name__ == "__main__":
    if not _pycaw_available:
        print("pycaw not installed. Run: pip install pycaw comtypes")
    else:
        print("Testing audio duck — play some music first.")
        print("Ducking in 2 seconds...")
        time.sleep(2)
        duck()
        print("Ducked! Restoring in 3 seconds...")
        time.sleep(3)
        unduck()
        print("Restored.")
