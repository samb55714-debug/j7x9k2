"""
JARVIS Clock Module
--------------------
Reads the real system time and gives you it in America/Chicago (Central)
time, regardless of what timezone your PC is actually set to.

Usage:
    from clock import get_current_time_str, get_greeting_line

    get_current_time_str()      -> "5:33 PM"
    get_greeting_line()         -> "Good evening, sir. It is 5:33 PM Central Time."

Requires (Windows only): pip install tzdata
  (Windows doesn't ship the IANA timezone database that zoneinfo needs;
   macOS/Linux already have it built in, so tzdata is a no-op there.)
"""

from datetime import datetime
from zoneinfo import ZoneInfo

CENTRAL = ZoneInfo("America/Chicago")


def get_now_central() -> datetime:
    """Real current time, converted to Central (handles CST/CDT automatically)."""
    return datetime.now(CENTRAL)


def get_current_time_str(with_seconds: bool = False) -> str:
    now = get_now_central()
    fmt = "%I:%M:%S %p" if with_seconds else "%I:%M %p"
    return now.strftime(fmt).lstrip("0")  # strip leading zero, e.g. "5:33 PM" not "05:33 PM"


def get_current_date_str() -> str:
    now = get_now_central()
    return now.strftime("%A, %B %d, %Y")


def _time_of_day_word(hour: int) -> str:
    if 5 <= hour < 12:
        return "morning"
    elif 12 <= hour < 17:
        return "afternoon"
    elif 17 <= hour < 21:
        return "evening"
    else:
        return "night"


def get_greeting_line() -> str:
    now = get_now_central()
    period = _time_of_day_word(now.hour)
    time_str = get_current_time_str()
    return f"Good {period}, sir. It is {time_str} Central Time."


if __name__ == "__main__":
    # Quick manual test: python clock.py
    print(get_current_time_str())
    print(get_current_date_str())
    print(get_greeting_line())
