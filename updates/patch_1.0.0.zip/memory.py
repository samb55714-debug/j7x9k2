# memory.py
# Simple reminder system for your JARVIS assistant

import json
import os
from datetime import datetime

REMINDERS_FILE = "reminders.json"

def load_reminders():
    """Load reminders from the JSON file."""
    if not os.path.exists(REMINDERS_FILE):
        return []
    try:
        with open(REMINDERS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def save_reminders(reminders):
    """Save the list of reminders to the JSON file."""
    with open(REMINDERS_FILE, "w", encoding="utf-8") as f:
        json.dump(reminders, f, indent=4)

def check_due_reminders():
    """
    Check which reminders are due right now.
    Returns a list of due reminder texts.
    Removes the due ones from the file after checking.
    """
    reminders = load_reminders()
    if not reminders:
        return []

    due = []
    still_pending = []
    now = datetime.now()

    for r in reminders:
        try:
            due_time = datetime.fromisoformat(r["time"])
            if due_time <= now:
                due.append(r["text"])
            else:
                still_pending.append(r)
        except Exception:
            # If the time format is broken, keep it for later
            still_pending.append(r)

    # Save only the ones that are still in the future
    save_reminders(still_pending)
    return due

def add_reminder(text, minutes_from_now=5):
    """
    Helper function: add a new reminder that will be due in X minutes.
    You can call this from main.py if you want.
    """
    reminders = load_reminders()
    due_time = datetime.now().timestamp() + (minutes_from_now * 60)
    due_time = datetime.fromtimestamp(due_time)

    reminders.append({
        "text": text,
        "time": due_time.isoformat()
    })
    save_reminders(reminders)
    print(f"Reminder added: '{text}' in {minutes_from_now} minutes.")