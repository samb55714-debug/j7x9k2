"""
JARVIS TTS - with audio ducking
Ducks other system audio before speaking, restores after.
"""

import numpy as np
import sounddevice as sd

_tts_engine = None
_speaker_name = "p236"
_cache = {}

try:
    from audio_duck import duck, unduck, is_available as duck_available
    _ducking = True
except ImportError:
    _ducking = False
    def duck(): pass
    def unduck(): pass


def _get_engine():
    global _tts_engine
    if _tts_engine is None:
        print("[tts] Loading voice model...")
        from TTS.api import TTS
        _tts_engine = TTS(model_name="tts_models/en/vctk/vits",
                          progress_bar=False, gpu=False)
        print("[tts] Voice model ready.")
    return _tts_engine


def warm_up():
    engine = _get_engine()
    common = ["Yes?", "Of course, sir.", "I didn't catch that, sir.",
              "Understood.", "Done.", "Right away, sir.", "Goodnight, sir."]
    print("[tts] Pre-caching common phrases...")
    for phrase in common:
        arr = engine.tts(text=phrase, speaker=_speaker_name)
        _cache[phrase.lower()] = np.array(arr, dtype=np.float32)
    print("[tts] Cache ready.")


def speak(text: str, on_amplitude=None, speaker: str = None):
    if not text or not text.strip():
        return

    engine = _get_engine()
    voice = speaker or _speaker_name
    key = text.strip().lower()

    if key in _cache:
        wav_array = _cache[key]
    else:
        wav_array = np.array(engine.tts(text=text, speaker=voice), dtype=np.float32)

    sample_rate = 22050
    chunk_size = 512
    idx = 0
    total = len(wav_array)

    # Duck other audio before speaking
    duck()

    try:
        def callback(outdata, frames, time_info, status):
            nonlocal idx
            end = min(idx + frames, total)
            chunk = wav_array[idx:end]
            if len(chunk) < frames:
                chunk = np.pad(chunk, (0, frames - len(chunk)))
            outdata[:, 0] = chunk
            if on_amplitude:
                rms = float(np.sqrt(np.mean(chunk ** 2))) if len(chunk) else 0.0
                on_amplitude(min(1.0, rms * 4.0))
            idx = end
            if idx >= total:
                raise sd.CallbackStop()

        with sd.OutputStream(samplerate=sample_rate, channels=1,
                             callback=callback, blocksize=chunk_size):
            while idx < total:
                sd.sleep(10)
    finally:
        # Always restore audio even if something goes wrong mid-speech
        unduck()
        if on_amplitude:
            on_amplitude(0.0)


if __name__ == "__main__":
    def _bar(a): print(f"\r[{'#'*int(a*30):<30}] {a:.2f}", end="")
    speak("Good evening, sir. All systems are online.", on_amplitude=_bar)
    print()
