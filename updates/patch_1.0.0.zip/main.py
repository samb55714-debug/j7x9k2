"""
JARVIS Main Loop v10
- Starts recording immediately when you speak after "Yes?"
- No fixed delay between wake word and command listening
- Instant commands still fire mid-stream for speed
"""

import sys
import threading
import numpy as np

from PyQt6.QtWidgets import QApplication
from startup_screen import run_startup_screen
from orb_overlay import JarvisOverlay, signals as orb_signals
from wake_word import listen_for_wake_word
from stt import transcribe, record_until_silence, warm_up as stt_warm_up
from fast_commands import listen_fast, _get_fast_model
from tts import speak, warm_up as tts_warm_up
from clock import get_greeting_line
from command_router import handle_command
from sleep_mode import is_sleeping, check_wake_command, set_sleeping
from text_input import CommandPalette, install_global_hotkey
from reminders import set_fire_callback

# Check for updates silently in background on startup
try:
    from updater import check_and_update_background
    _updater_available = True
except ImportError:
    _updater_available = False

try:
    from discord_bot import start_discord_bot
    _discord_available = True
except ImportError:
    _discord_available = False

_desktop_mode = False

def _on_desktop_mode(active: bool):
    global _desktop_mode
    _desktop_mode = active

orb_signals.desktop_mode.connect(_on_desktop_mode)


def speak_with_orb(text: str, title: str = "JARVIS"):
    if not text:
        return
    _shown = [False]
    def on_amp(a):
        if not _shown[0]:
            orb_signals.show_message.emit(title, text)
            _shown[0] = True
        orb_signals.amplitude_changed.emit(a)
    speak(text, on_amplitude=on_amp)


def show_live(title: str, body: str):
    orb_signals.show_live_text.emit(title, body)


def process_command(text: str):
    if not text:
        speak_with_orb("I didn't catch that, sir.")
        return
    print(f'[JARVIS] Command: "{text}"')
    show_live("You said", text)
    response = handle_command(text)
    if response:
        speak_with_orb(response)
    print("[JARVIS] Ready.\n")


def handle_wake():
    global _desktop_mode

    # Sleep mode: only listen for wake command
    if is_sleeping():
        audio = record_until_silence(max_seconds=4.0)
        text = transcribe(audio)
        if text and check_wake_command(text.lower()):
            set_sleeping(False)
            orb_signals.dock_to_corner.emit(False)
            orb_signals.desktop_mode.emit(False)
            speak_with_orb("Good morning, sir. I'm back online.")
        return

    print("\n[JARVIS] Activated.")

    if not _desktop_mode:
        orb_signals.dock_to_corner.emit(False)
        orb_signals.desktop_mode.emit(False)
    else:
        show_live("JARVIS", "Listening...")

    # Speak "Yes?" in a background thread so recording can start
    # simultaneously — no gap between the beep and listening
    ack_done = threading.Event()
    def say_yes():
        speak_with_orb("Yes?")
        ack_done.set()
    threading.Thread(target=say_yes, daemon=True).start()

    # Start the fast command listener immediately
    # It will buffer audio from the moment it starts
    def on_instant(canonical: str):
        print(f"[JARVIS] Instant: {canonical}")
        show_live("JARVIS", canonical)
        response = handle_command(canonical)
        if response:
            speak_with_orb(response)
        print("[JARVIS] Ready.\n")

    def on_full_audio(audio: np.ndarray):
        text = transcribe(audio)
        process_command(text)

    # Wait for "Yes?" to finish before processing to avoid
    # transcribing the TTS output as a command
    ack_done.wait(timeout=3.0)

    listen_fast(
        on_instant_command=on_instant,
        on_full_audio=on_full_audio,
    )


def voice_loop():
    print("[JARVIS] Loading models...")
    tts_warm_up()
    stt_warm_up()
    _get_fast_model()
    set_fire_callback(speak_with_orb)
    print("[JARVIS] All systems ready.")

    # Check for updates silently — downloads and restarts if update found
    if _updater_available:
        def _on_update(remote):
            orb_signals.show_message.emit("JARVIS", f"Updating to v{remote['version']}...")
            speak_with_orb(f"Updating to version {remote['version']}, sir. One moment.")
        def _on_done(success):
            if not success:
                speak_with_orb("Update failed, sir. Continuing with current version.")
        check_and_update_background(
            on_update_available=_on_update,
            on_update_complete=_on_done,
            silent=True
        )

    if _discord_available:
        try:
            start_discord_bot()
        except Exception as e:
            print(f"[JARVIS] Discord unavailable: {e}")

    speak_with_orb(get_greeting_line())
    print("[JARVIS] Listening for 'Hey Jarvis'...")
    listen_for_wake_word(on_detected=handle_wake)


def main():
    app = QApplication(sys.argv)
    selected_mode = run_startup_screen()
    print(f"[JARVIS] Starting in {selected_mode} mode...")

    overlay = JarvisOverlay()
    overlay.show()

    if selected_mode == "desktop":
        orb_signals.dock_to_corner.emit(True)
        orb_signals.desktop_mode.emit(True)
    else:
        orb_signals.dock_to_corner.emit(False)
        orb_signals.desktop_mode.emit(False)

    palette = CommandPalette(on_command=process_command)
    install_global_hotkey(palette)

    t = threading.Thread(target=voice_loop, daemon=True)
    t.start()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
