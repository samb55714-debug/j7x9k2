"""
JARVIS App Launcher v2
-----------------------
Opens any installed app on Windows reliably.
Uses multiple strategies in order:
  1. Direct executable (instant for known apps)
  2. Windows Search via Start Menu (works for ANY installed app)
  3. Shell execute (fallback for Store apps)
"""

import subprocess
import time
import os
import re
import pyautogui

# Direct launch - these open instantly without needing Windows Search
DIRECT_APPS = {
    # Browsers
    "chrome": "chrome",
    "google chrome": "chrome",
    "edge": "msedge",
    "microsoft edge": "msedge",
    "firefox": "firefox",
    "opera": "opera",
    "brave": "brave",

    # Microsoft Office
    "word": "winword",
    "microsoft word": "winword",
    "excel": "excel",
    "microsoft excel": "excel",
    "powerpoint": "powerpnt",
    "microsoft powerpoint": "powerpnt",
    "outlook": "outlook",
    "onenote": "onenote",
    "teams": "teams",
    "microsoft teams": "teams",

    # Windows built-ins
    "notepad": "notepad",
    "calculator": "calc",
    "paint": "mspaint",
    "file explorer": "explorer",
    "explorer": "explorer",
    "task manager": "taskmgr",
    "settings": "ms-settings:",
    "control panel": "control",
    "command prompt": "cmd",
    "cmd": "cmd",
    "powershell": "powershell",
    "snipping tool": "snippingtool",
    "magnifier": "magnify",
    "wordpad": "wordpad",
    "registry editor": "regedit",
    "device manager": "devmgmt.msc",
    "disk management": "diskmgmt.msc",
    "event viewer": "eventvwr",
    "services": "services.msc",
    "notepad++": "notepad++",

    # Common apps (if installed)
    "spotify": "spotify",
    "discord": "discord",
    "steam": "steam",
    "vlc": "vlc",
    "obs": "obs64",
    "obs studio": "obs64",
    "zoom": "zoom",
    "slack": "slack",
    "telegram": "telegram",
    "whatsapp": "whatsapp",
    "signal": "signal",
    "vs code": "code",
    "visual studio code": "code",
    "vscode": "code",
    "git bash": "git-bash",
    "7-zip": "7zfm",
    "winrar": "winrar",
    "audacity": "audacity",
    "gimp": "gimp-2.10",
    "blender": "blender",
    "handbrake": "handbrake",
    "putty": "putty",
    "filezilla": "filezilla",
    "postman": "postman",
    "tor browser": "tor browser",
}

# Windows Store / UWP apps - opened via shell: protocol
STORE_APPS = {
    "xbox": "shell:AppsFolder\\Microsoft.XboxApp_8wekyb3d8bbwe!Microsoft.XboxApp",
    "xbox game bar": "shell:AppsFolder\\Microsoft.XboxGamingOverlay_8wekyb3d8bbwe!App",
    "photos": "shell:AppsFolder\\Microsoft.Windows.Photos_8wekyb3d8bbwe!App",
    "camera": "shell:AppsFolder\\Microsoft.WindowsCamera_8wekyb3d8bbwe!App",
    "mail": "shell:AppsFolder\\microsoft.windowscommunicationsapps_8wekyb3d8bbwe!microsoft.windowsLive.mail",
    "maps": "shell:AppsFolder\\Microsoft.WindowsMaps_8wekyb3d8bbwe!App",
    "weather": "shell:AppsFolder\\Microsoft.BingWeather_8wekyb3d8bbwe!App",
    "news": "shell:AppsFolder\\Microsoft.BingNews_8wekyb3d8bbwe!AppexNews",
    "groove music": "shell:AppsFolder\\Microsoft.ZuneMusic_8wekyb3d8bbwe!Microsoft.ZuneMusic",
    "movies": "shell:AppsFolder\\Microsoft.ZuneVideo_8wekyb3d8bbwe!Microsoft.ZuneVideo",
    "solitaire": "shell:AppsFolder\\Microsoft.MicrosoftSolitaireCollection_8wekyb3d8bbwe!App",
    "minecraft": "shell:AppsFolder\\Microsoft.MinecraftUWP_8wekyb3d8bbwe!App",
}


def _normalize(name: str) -> str:
    """Clean up spoken app name for matching."""
    n = name.lower().strip()
    # Remove filler words
    for filler in ["the ", "app ", "application ", "program ", "game "]:
        n = n.replace(filler, "")
    return n.strip()


def _try_direct(name: str) -> bool:
    """Try launching via known executable name. Returns True if launched."""
    n = _normalize(name)
    # Exact match
    if n in DIRECT_APPS:
        try:
            subprocess.Popen(f'start "" "{DIRECT_APPS[n]}"', shell=True)
            return True
        except Exception:
            pass
    # Partial match
    for key, exe in DIRECT_APPS.items():
        if n in key or key in n:
            try:
                subprocess.Popen(f'start "" "{exe}"', shell=True)
                return True
            except Exception:
                continue
    return False


def _try_store_app(name: str) -> bool:
    """Try launching a Windows Store/UWP app."""
    n = _normalize(name)
    for key, shell_path in STORE_APPS.items():
        if n in key or key in n:
            try:
                subprocess.Popen(f'explorer.exe "{shell_path}"', shell=True)
                return True
            except Exception:
                continue
    return False


def _try_windows_search(name: str) -> bool:
    """
    Uses Windows Search (Start Menu) to find and open any app.
    More reliable version with proper timing.
    """
    try:
        # Close any open Start Menu first
        pyautogui.press("escape")
        time.sleep(0.2)

        # Open Start Menu
        pyautogui.press("win")
        time.sleep(1.0)  # wait for Start Menu to fully open

        # Clear search and type app name slowly
        pyautogui.hotkey("ctrl", "a")
        time.sleep(0.1)

        # Type character by character for reliability
        for char in name:
            pyautogui.write(char, interval=0.05)
        time.sleep(1.2)  # wait for search results to populate

        # Press Enter to open the top result
        pyautogui.press("enter")
        time.sleep(0.5)
        return True
    except Exception as e:
        print(f"[app_launcher] Windows Search failed: {e}")
        return False


def _try_run_dialog(name: str) -> bool:
    """Last resort - tries Win+R with the app name directly."""
    try:
        pyautogui.hotkey("win", "r")
        time.sleep(0.5)
        pyautogui.write(name, interval=0.05)
        time.sleep(0.2)
        pyautogui.press("enter")
        return True
    except Exception:
        return False


def open_app(name: str) -> str:
    """
    Opens any app by name. Tries multiple strategies in order.
    """
    print(f"[app_launcher] Opening: '{name}'")
    cleaned = _normalize(name)

    # Strategy 1: Direct executable
    if _try_direct(name):
        return f"Opening {name}, sir."

    # Strategy 2: Windows Store app
    if _try_store_app(name):
        return f"Opening {name}, sir."

    # Strategy 3: Windows Search (works for everything including Roblox,
    # Epic Games, game launchers, any installed app)
    if _try_windows_search(name):
        return f"Searching for {name} and opening the top result, sir."

    return f"I couldn't find {name}, sir. Make sure it's installed."


def open_with_search_only(name: str) -> str:
    """Opens Windows Search with the query but doesn't auto-press Enter."""
    pyautogui.press("escape")
    time.sleep(0.2)
    pyautogui.press("win")
    time.sleep(0.8)
    pyautogui.write(name, interval=0.05)
    return f"Searching for {name}."


if __name__ == "__main__":
    import sys
    app_name = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "Notepad"
    print(open_app(app_name))
